package com.icesi.taller4.test.dao;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.math.BigDecimal;
import java.time.LocalTime;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.icesi.taller4.dao.scheduledDao;
import com.icesi.taller4.model.TsscTimecontrol;


@ExtendWith(SpringExtension.class)
@ContextConfiguration("/applicationContext.xml")
@Rollback(false)
@TestInstance(Lifecycle.PER_METHOD)
public class ScheduledDaoTest {
	
	@Autowired
	private scheduledDao scheduledDao;
	
	private TsscTimecontrol timeControl;
	
	@BeforeEach
	public void prepareCase() {
		
		for (TsscTimecontrol tOption : scheduledDao.findAll()) {
			scheduledDao.delete(tOption);
		}		
	
		//TimeControl
		timeControl = new TsscTimecontrol();
		timeControl.setName("controlador");
		timeControl.setIntervalRunning(BigDecimal.TEN);
		timeControl.setLastPlayTime(LocalTime.NOON);
		timeControl.setAutostart("YES");
		scheduledDao.save(timeControl);
		
		}
	
	@Test
	@DisplayName("Save a new timecontrol")
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void save() {
		
		assertNotNull(scheduledDao);
		TsscTimecontrol target = new TsscTimecontrol();
		target.setName("hola");
		target.setIntervalRunning(BigDecimal.TEN);
		target.setLastPlayTime(LocalTime.NOON);
		target.setAutostart("YES");
		scheduledDao.save(target);
		assertNotNull(scheduledDao.findById(target.getId()));
		assertEquals(target, scheduledDao.findById(target.getId()));
		
	}

	
	@Test
	@DisplayName("Update a timecontrol already in the system")
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void update() {
		
		assertNotNull(scheduledDao);
		timeControl.setName("hola updated");
		scheduledDao.update(timeControl);
		assertNotNull(scheduledDao.findById(timeControl.getId()));
		assertEquals(timeControl.getName(), scheduledDao.findById(timeControl.getId()).getName());
		
		timeControl.setName("original");
		scheduledDao.update(timeControl);
		assertEquals(timeControl.getName(), scheduledDao.findById(timeControl.getId()).getName());
		
	}
	
	@Test
	@DisplayName("Delete a timecontrol already in the system")
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void delete() {
		
		assertNotNull(scheduledDao);
		scheduledDao.delete(timeControl);	
		assertFalse(scheduledDao.findById(timeControl.getId())!=null);
		
	}
	
	@Test
	@DisplayName("Find a timecontrol by the id")
	@Transactional(readOnly=true, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void findById() {
		
		assertNotNull(scheduledDao);
		assertNotNull(scheduledDao.findById(timeControl.getId()));
		assertEquals(timeControl.getName(), scheduledDao.findById(timeControl.getId()).getName());
		
	}
	
	@Test
	@DisplayName("Find all the timecontrols in the list")
	@Transactional(readOnly=true, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void findAll() {
		
		assertNotNull(scheduledDao);
		List<TsscTimecontrol> timeControls =  scheduledDao.findAll();
		assertEquals(1, timeControls.size());
		assertEquals(timeControl.getName(), timeControls.get(0).getName());
		
	}
	

}
