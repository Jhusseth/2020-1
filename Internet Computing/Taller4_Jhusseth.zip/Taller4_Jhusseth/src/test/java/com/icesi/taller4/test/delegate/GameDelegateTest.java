package com.icesi.taller4.test.delegate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;

import com.icesi.taller4.delegate.BussinessGameDelegate;
import com.icesi.taller4.model.TsscGame;

@ExtendWith(SpringExtension.class)
@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
class GameDelegateTest {
	
	@Mock 
	private RestTemplate restTemplate;
	
	@InjectMocks
	private BussinessGameDelegate businessGameDelegate;
	
	private TsscGame game;
	
	@Autowired
	public GameDelegateTest(BussinessGameDelegate GameDelegate) {
		this.businessGameDelegate = GameDelegate;
	}
	
	@BeforeEach
	public void setUp() {
		game = new TsscGame();
	}

	@Test
	void testSaveGame() {
		assertNotNull(businessGameDelegate);
		
		when(restTemplate.postForObject("http://localhost:8080/api/games", game, TsscGame.class)).thenReturn(game);
		
		assertTrue(businessGameDelegate.save(game)!=null);
	}
	
	@Test
	void testUpdateGame() {
		assertNotNull(businessGameDelegate);
		
		when(restTemplate.postForObject("http://localhost:8080/api/games", game, TsscGame.class)).thenReturn(game);
		
		assertTrue(businessGameDelegate.save(game)!=null);
		
		game.setName("Game1");
		
		businessGameDelegate.update(game);
	}
	
	@Test
	void testDeleteGame() {
		assertNotNull(businessGameDelegate);
		
		when(restTemplate.postForObject("http://localhost:8080/api/games", game, TsscGame.class)).thenReturn(game);
		
		assertTrue(businessGameDelegate.save(game)!=null);
		
		businessGameDelegate.delete(game.getId());
	}
	
	@Test
	void testFindByIdGame() {
		assertNotNull(businessGameDelegate);
		
		when(restTemplate.postForObject("http://localhost:8080/api/games", game, TsscGame.class)).thenReturn(game);
		
		assertTrue(businessGameDelegate.save(game)!=null);
		
		when(restTemplate.getForObject("http://localhost:8080/api/games/"+game.getId(), TsscGame.class)).thenReturn(game);
		
		assertTrue(businessGameDelegate.findById(game.getId())!=null);
	}
	
	@Test
	void testFindAllGame() {
		assertNotNull(businessGameDelegate);
		
		ArrayList<TsscGame> list  = new ArrayList<TsscGame>();
		
		list.add(game);
		
		when(restTemplate.postForObject("http://localhost:8080/api/games", game, TsscGame.class)).thenReturn(game);
		
		assertTrue(businessGameDelegate.save(game)!=null);
		
		when(restTemplate.getForObject("http://localhost:8080/api/games", Iterable.class)).thenReturn(list);
		
		assertTrue(((ArrayList<TsscGame>)businessGameDelegate.findAll()).get(0)!=null);
	}

}
