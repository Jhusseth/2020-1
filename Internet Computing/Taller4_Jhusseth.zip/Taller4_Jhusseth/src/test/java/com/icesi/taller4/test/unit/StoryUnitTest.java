package com.icesi.taller4.test.unit;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

import com.icesi.taller4.dao.GameDaoImp;
import com.icesi.taller4.dao.StoryDaoImp;
import com.icesi.taller4.exception.StoryException;
import com.icesi.taller4.model.TsscGame;
import com.icesi.taller4.model.TsscStory;
import com.icesi.taller4.service.GameService;
import com.icesi.taller4.service.StoryService;


@SpringBootTest
@ContextConfiguration(classes = StoryUnitTest.class)
@TestInstance(Lifecycle.PER_METHOD)
class StoryUnitTest {
	
	@Mock
	private  GameDaoImp gameRepository;
	@Mock
	private  StoryDaoImp storyRepository;

	
	@InjectMocks
	private  GameService gameServ;
	@InjectMocks
	private  StoryService stoServ;

	
	
	private TsscGame correctGame;
	
	private TsscStory correctStory;


	
	@BeforeEach
	public  void prepareCase() {
		//Game
		correctGame = new TsscGame();
		correctGame.setName("Assasins");
		correctGame.setNGroups(9);
		correctGame.setNSprints(10);
		//Story
		correctStory = new TsscStory();
		correctStory.setDescription("Es una bichiyal");
		correctStory.setTsscGame(correctGame);
		correctStory.setBusinessValue(BigDecimal.valueOf(50000));
		correctStory.setPriority(BigDecimal.TEN);
		correctStory.setInitialSprint(BigDecimal.ONE);
	}
	

	
	@Test
	@DisplayName("Save a null story")
	public void saveNullStory() {
		
		try {
			assertNull(stoServ.save(null,correctGame.getId()));
		} catch (StoryException e) {
			e.printStackTrace();
		}
		verifyNoMoreInteractions(storyRepository);
		
	}
	
	
	@Test
	@DisplayName("Save a story with an existing game")
	public void saveStoryWithExistingGame() {
		
		when(storyRepository.save(correctStory)).thenReturn(correctStory);
		when(gameRepository.findById(correctGame.getId())).thenReturn((TsscGame) Optional.ofNullable(null).get());
		try {
			assertNull(stoServ.save(correctStory,correctGame.getId()));
		} catch (StoryException e) {
			e.printStackTrace();
		}
		verify(gameRepository).findById(correctGame.getId());
		verifyNoMoreInteractions(storyRepository);
		
	}
	
	
	@Test
	@DisplayName("Save an invalid story with an existing game")
	public void saveInvalidStoryWithExistingGame() {
		
		correctStory.setInitialSprint(BigDecimal.valueOf(0));
		when(storyRepository.save(correctStory)).thenReturn(correctStory);
		when(gameRepository.findById(correctGame.getId())).thenReturn(Optional.of(correctGame).get());
		try {
			assertNull(stoServ.save(correctStory,correctGame.getId()));
		} catch (StoryException e) {
			e.printStackTrace();
		}
		verifyNoMoreInteractions(storyRepository);
		
	}
	
	@Test
	@DisplayName("Save a story with a non-existing game")
	public void saveStoryWithNonExistingGame() {
		
		correctStory.setInitialSprint(BigDecimal.valueOf(0));
		when(storyRepository.save(correctStory)).thenReturn(correctStory);
		when(gameRepository.findById(correctGame.getId())).thenReturn((TsscGame) Optional.ofNullable(null).get());
		try {
			assertNull(stoServ.save(correctStory,correctGame.getId()));
		} catch (StoryException e) {
			e.printStackTrace();
		}
		verifyNoMoreInteractions(storyRepository);
		
	}
	
	
	@Test
	@DisplayName("Modify a non-existing story")
	public void modifyNonExistingStory() {
		
		TsscStory modifiedStory = correctStory;
		modifiedStory.setDescription("The modified story doesnt exist");
		when(storyRepository.findById(modifiedStory.getId())).thenReturn((TsscStory) Optional.ofNullable(null).get());
		try {
			assertNull(stoServ.update(modifiedStory));
		} catch (StoryException e) {
			e.printStackTrace();
		}
		verify(storyRepository).findById(modifiedStory.getId());
		verifyNoMoreInteractions(storyRepository); 
		
	}
	
	@Test
	@DisplayName("Modify a story with wrong values")
	public void modifyStoryWithWrongValues() {
		
		TsscStory modifiedStory = correctStory;
		Optional<TsscStory> tOption = Optional.of(modifiedStory);
		modifiedStory.setDescription("Modified");
		modifiedStory.setBusinessValue(BigDecimal.valueOf(0));;
		when(storyRepository.findById(modifiedStory.getId())).thenReturn(tOption.get());
		try {
			assertNull(stoServ.update(modifiedStory));
		} catch (StoryException e) {
			e.printStackTrace();
		}
		verify(storyRepository).findById(modifiedStory.getId());
		verifyNoMoreInteractions(storyRepository); 	
		
	}
	
	@Test
	@DisplayName("Modify a story with a non-existing game")
	public void modifyStoryWithNonExistingGame() {
		
		TsscStory modifiedStory = correctStory;
		TsscGame modifiedGame = correctGame;
		modifiedGame.setName("Modified");
		Optional<TsscStory> tOption = Optional.of(modifiedStory);
		when(storyRepository.findById(modifiedStory.getId())).thenReturn(tOption.get());
		when(gameRepository.findById(modifiedGame.getId())).thenReturn((TsscGame) Optional.ofNullable(null).get());
		when(storyRepository.save(modifiedStory)).thenReturn(modifiedStory);
		try {
			assertNull(stoServ.update(modifiedStory));
		} catch (StoryException e) {
			e.printStackTrace();
		}
		verify(gameRepository).findById(modifiedGame.getId());
		verify(storyRepository).findById(modifiedStory.getId());
		verifyNoMoreInteractions(storyRepository); 	
		
	}

}
