package com.icesi.taller4.test.delegate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;

import com.icesi.taller4.delegate.BusinessAdminDelegate;
import com.icesi.taller4.model.TsscAdmin;

@ExtendWith(SpringExtension.class)
@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
class AdminDelegateTest {
	
	@Mock 
	private RestTemplate restTemplate;
	
	@InjectMocks
	private BusinessAdminDelegate businessAdminDelegate;
	
	private TsscAdmin admin;
	
	@Autowired
	public AdminDelegateTest(BusinessAdminDelegate AdminDelegate) {
		this.businessAdminDelegate = AdminDelegate;
	}
	
	@BeforeEach
	public void setUp() {
		admin = new TsscAdmin();
	}

	@Test
	void testSaveAdmin() {
		assertNotNull(businessAdminDelegate);
		
		when(restTemplate.postForObject("http://localhost:8080/api/admins", admin, TsscAdmin.class)).thenReturn(admin);
		
		assertTrue(businessAdminDelegate.save(admin)!=null);
	}
	
	@Test
	void testUpdateAdmin() {
		assertNotNull(businessAdminDelegate);
		
		when(restTemplate.postForObject("http://localhost:8080/api/admins", admin, TsscAdmin.class)).thenReturn(admin);
		
		assertTrue(businessAdminDelegate.save(admin)!=null);
		
		admin.setPassword("123");
		
		businessAdminDelegate.update(admin);
	}
	
	@Test
	void testDeleteAdmin() {
		assertNotNull(businessAdminDelegate);
		
		when(restTemplate.postForObject("http://localhost:8080/api/admins", admin, TsscAdmin.class)).thenReturn(admin);
		
		assertTrue(businessAdminDelegate.save(admin)!=null);
		
		businessAdminDelegate.delete(admin.getId());
	}
	
	@Test
	void testFindByIdAdmin() {
		assertNotNull(businessAdminDelegate);
		
		when(restTemplate.postForObject("http://localhost:8080/api/admins", admin, TsscAdmin.class)).thenReturn(admin);
		
		assertTrue(businessAdminDelegate.save(admin)!=null);
		
		when(restTemplate.getForObject("http://localhost:8080/api/admins/"+admin.getId(), TsscAdmin.class)).thenReturn(admin);
		
		assertTrue(businessAdminDelegate.findById(admin.getId())!=null);
	}
	
	@Test
	void testFindAllAdmin() {
		assertNotNull(businessAdminDelegate);
		
		ArrayList<TsscAdmin> list  = new ArrayList<TsscAdmin>();
		
		list.add(admin);
		
		when(restTemplate.postForObject("http://localhost:8080/api/admins", admin, TsscAdmin.class)).thenReturn(admin);
		
		assertTrue(businessAdminDelegate.save(admin)!=null);
		
		when(restTemplate.getForObject("http://localhost:8080/api/admins", Iterable.class)).thenReturn(list);
		
		assertTrue(((ArrayList<TsscAdmin>)businessAdminDelegate.findAll()).get(0)!=null);
	}

}
