package com.icesi.taller4.test.delegate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;

import com.icesi.taller4.delegate.BussinessStoryDelegate;
import com.icesi.taller4.model.TsscStory;

@ExtendWith(SpringExtension.class)
@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
class StoryDelegateTest {
	
	@Mock 
	private RestTemplate restTemplate;
	
	@InjectMocks
	private BussinessStoryDelegate businessStoryDelegate;
	
	private TsscStory story;
	
	@Autowired
	public StoryDelegateTest(BussinessStoryDelegate StoryDelegate) {
		this.businessStoryDelegate = StoryDelegate;
	}
	
	@BeforeEach
	public void setUp() {
		story = new TsscStory();
	}

	@Test
	void testCreateStory() {
		assertNotNull(businessStoryDelegate);
		
		when(restTemplate.postForObject("http://localhost:8080/api/stories/0", story, TsscStory.class)).thenReturn(story);
		
		assertTrue(businessStoryDelegate.save(story,0)!=null);
	}
	
	@Test
	void testUpdateStory() {
		assertNotNull(businessStoryDelegate);
		
		when(restTemplate.postForObject("http://localhost:8080/api/stories/0", story, TsscStory.class)).thenReturn(story);
		
		assertTrue(businessStoryDelegate.save(story,0)!=null);
		
		story.setDescription("New Story");
		
		businessStoryDelegate.update(story);
	}
	
	@Test
	void testDeleteStory() {
		assertNotNull(businessStoryDelegate);
		
		when(restTemplate.postForObject("http://localhost:8080/api/stories/0", story, TsscStory.class)).thenReturn(story);
		
		assertTrue(businessStoryDelegate.save(story,0)!=null);
		
		businessStoryDelegate.delete(story.getId());
	}
	
	@Test
	void testGetStory() {
		assertNotNull(businessStoryDelegate);
		
		when(restTemplate.postForObject("http://localhost:8080/api/stories/0", story, TsscStory.class)).thenReturn(story);
		
		assertTrue(businessStoryDelegate.save(story,0)!=null);
		
		when(restTemplate.getForObject("http://localhost:8080/api/stories/"+story.getId(), TsscStory.class)).thenReturn(story);
		
		assertTrue(businessStoryDelegate.findById(story.getId())!=null);
	}
	
	@Test
	void testFindAllStory() {
		assertNotNull(businessStoryDelegate);
		
		ArrayList<TsscStory> list  = new ArrayList<TsscStory>();
		
		list.add(story);
		
		when(restTemplate.postForObject("http://localhost:8080/api/stories/0", story, TsscStory.class)).thenReturn(story);
		
		assertTrue(businessStoryDelegate.save(story,0)!=null);
		
		when(restTemplate.getForObject("http://localhost:8080/api/stories", Iterable.class)).thenReturn(list);
		
		assertTrue(((ArrayList<TsscStory>)businessStoryDelegate.findAll()).get(0)!=null);
	}

}
