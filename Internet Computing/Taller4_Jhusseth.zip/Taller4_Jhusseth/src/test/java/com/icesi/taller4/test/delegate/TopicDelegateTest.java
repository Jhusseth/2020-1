package com.icesi.taller4.test.delegate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;

import com.icesi.taller4.delegate.BussinessTopicDelegate;
import com.icesi.taller4.model.TsscTopic;

@ExtendWith(SpringExtension.class)
@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
class TopicDelegateTest {
	
	@Mock 
	private RestTemplate restTemplate;
	
	@InjectMocks
	private BussinessTopicDelegate businessTopicDelegate;
	
	private TsscTopic topic;
	
	@Autowired
	public TopicDelegateTest(BussinessTopicDelegate TopicDelegate) {
		this.businessTopicDelegate = TopicDelegate;
	}
	
	@BeforeEach
	public void setUpOne() {
		topic = new TsscTopic();
	}

	@Test
	void testSaveTopic() {
		assertNotNull(businessTopicDelegate);
		
		when(restTemplate.postForObject("http://localhost:8080/api/topics", topic, TsscTopic.class)).thenReturn(topic);
		
		assertTrue(businessTopicDelegate.save(topic)!=null);
	}
	
	@Test
	void testUpdateTopic() {
		assertNotNull(businessTopicDelegate);
		
		when(restTemplate.postForObject("http://localhost:8080/api/topics", topic, TsscTopic.class)).thenReturn(topic);
		
		assertTrue(businessTopicDelegate.save(topic)!=null);
		
		topic.setName("Topic 1");
		
		businessTopicDelegate.update(topic);
	}
	
	@Test
	void testDeleteTopic() {
		assertNotNull(businessTopicDelegate);
		
		when(restTemplate.postForObject("http://localhost:8080/api/topics", topic, TsscTopic.class)).thenReturn(topic);
		
		assertTrue(businessTopicDelegate.save(topic)!=null);
		
		businessTopicDelegate.delete(topic.getId());
	}
	
	@Test
	void testFindByIdTopic() {
		assertNotNull(businessTopicDelegate);
		
		when(restTemplate.postForObject("http://localhost:8080/api/topics", topic, TsscTopic.class)).thenReturn(topic);
		
		assertTrue(businessTopicDelegate.save(topic)!=null);
		
		when(restTemplate.getForObject("http://localhost:8080/api/topics/"+topic.getId(), TsscTopic.class)).thenReturn(topic);
		
		assertTrue(businessTopicDelegate.findById(topic.getId())!=null);
	}
	
	@Test
	void testFindAllTopic() {
		assertNotNull(businessTopicDelegate);
		
		ArrayList<TsscTopic> list  = new ArrayList<TsscTopic>();
		
		list.add(topic);
		
		when(restTemplate.postForObject("http://localhost:8080/api/topics", topic, TsscTopic.class)).thenReturn(topic);
		
		assertTrue(businessTopicDelegate.save(topic)!=null);
		
		when(restTemplate.getForObject("http://localhost:8080/api/topics", Iterable.class)).thenReturn(list);
		
		assertTrue(((ArrayList<TsscTopic>)businessTopicDelegate.findAll()).get(0)!=null);
	}

}
