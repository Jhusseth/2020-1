package com.icesi.taller4.test.dao;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.icesi.taller4.dao.TopicDaoImp;
import com.icesi.taller4.model.TsscTopic;


@ExtendWith(SpringExtension.class)
@ContextConfiguration("/applicationContext.xml")
@Rollback(false)
@TestInstance(Lifecycle.PER_METHOD)
public class TopicDaoTest {
	
	@Autowired
	private TopicDaoImp topicDao;
	
	private TsscTopic topic;
	
	public void setUp() {
		
		topic = new TsscTopic();
		topic.setName("topic 1");
		topic.setDefaultGroups(3);
		topic.setDefaultSprints(2);
		topic.setDescription("first topic descriptiion");
		topic.setGroupPrefix("first prefix group");
		
		topicDao.save(topic);
	}
	
	@Test
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testSaveTopic() {
		
		
		TsscTopic topic = new TsscTopic();
		topic.setName("topic 1");
		topic.setDefaultGroups(3);
		topic.setDefaultSprints(2);
		topic.setDescription("first topic descriptiion");
		topic.setGroupPrefix("first prefix group");
		
		assertNotNull(topicDao);
		
		try {
			topicDao.save(topic);
		}catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testUpdate() {
		setUp();
		topic.setName("topic 2");
		topic.setDefaultGroups(3);
		topic.setDefaultSprints(2);
		topic.setDescription("change topic descriptiion");
		topic.setGroupPrefix("change prefix group");
		assertNotNull(topicDao);
		topicDao.update(topic);
		
		assertEquals(topic.getName(), "topic 2");
		
	}
	
	@Test
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testDelete() {
		setUp();
		assertNotNull(topicDao);
		topicDao.delete(topic);
		assertThat(topicDao.findAll().size()==0);
		
	}
	
	@Test
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testFindById () {
		setUp();
		assertNotNull(topicDao);
		TsscTopic tp = topicDao.findById((long)1);
		assertNotNull(tp);
		
	}
	
	@Test
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testFindByName () {
		setUp();
		assertNotNull(topicDao);
		@SuppressWarnings("unchecked")
		List<TsscTopic> tp = (List<TsscTopic>) topicDao.findByName("");
		
		assertThat(tp.size()>=1);
		
		if(tp.size()>0) {
			assertNotNull(tp);
			TsscTopic result = tp.get(0);
			assertEquals(result.getName(), "topic 1");
			assertEquals(result.getDescription(), "first topic descriptiion");
		}
	
		
	}
	
	@Test
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testFindByDescription() {
		setUp();
		assertNotNull(topicDao);
		@SuppressWarnings("unchecked")
		List<TsscTopic> tp = (List<TsscTopic>) topicDao.findByDescription("");

		assertThat(tp.size()>=1);
		
		if(tp.size()>0) {
			assertNotNull(tp);
			TsscTopic result = tp.get(0);
			assertEquals(result.getName(), "topic 1");
			assertEquals(result.getDescription(), "first topic descriptiion");
		}
	}
	
	@Test
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testFindAll() {
		
		setUp();
		TsscTopic topic = new TsscTopic();
		topic.setName("topic 2");
		topic.setDefaultGroups(3);
		topic.setDefaultSprints(2);
		topic.setDescription("second topic descriptiion");
		topic.setGroupPrefix("second prefix group");
		
		assertNotNull(topicDao);
		topicDao.save(topic);
		
		assertEquals(2, topicDao.findAll().size());
		
		
	}

}
