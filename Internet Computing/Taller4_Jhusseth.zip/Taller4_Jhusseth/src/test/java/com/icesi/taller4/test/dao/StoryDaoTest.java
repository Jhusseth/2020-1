package com.icesi.taller4.test.dao;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;

import org.junit.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.icesi.taller4.dao.StoryDao;
import com.icesi.taller4.model.TsscStory;

@ExtendWith(SpringExtension.class)
@ContextConfiguration("/applicationContext.xml")
@Rollback(false)
@TestInstance(Lifecycle.PER_METHOD)
public class StoryDaoTest {
	
	@Autowired
	private StoryDao storyDao;
	
	private TsscStory story;
	
	
	public void setUp() {
		story = new TsscStory();
		story.setAltDescripton("first alt description");
		story.setAltDescShown("first alt description show");
		story.setDescription("first description");
		story.setNumber(new BigDecimal(1));
		story.setInitialSprint(new BigDecimal(1));
		story.setPriority(new BigDecimal(1));
		story.setBusinessValue(new BigDecimal(1));
		
		storyDao.save(story);
	}
	
	@Test
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testSaveStory() {
		TsscStory story = new TsscStory();
		story.setAltDescripton("first alt description");
		story.setAltDescShown("first alt description show");
		story.setDescription("first description");
		story.setNumber(new BigDecimal(1));
		story.setInitialSprint(new BigDecimal(1));
		story.setPriority(new BigDecimal(1));
		story.setBusinessValue(new BigDecimal(1));
		
		assertNotNull(storyDao);
		
		try {
			storyDao.save(story);
		}catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testUpdate() {
		setUp();
		story.setAltDescripton("change alt description");
		story.setAltDescShown("change alt description show");
		story.setDescription("change description");
		story.setNumber(new BigDecimal(1));
		story.setInitialSprint(new BigDecimal(1));
		story.setPriority(new BigDecimal(1));
		story.setBusinessValue(new BigDecimal(1));
		
		assertNotNull(storyDao);
		storyDao.update(story);
		assertNotNull(storyDao.findById(story.getId()));
		story.setNumber(new BigDecimal(1));
		storyDao.update(story);
		//assertEquals(story.getNumber(), storyDao.findById(story.getId()).getNumber());
		
		
	}
	
	@Test
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testDelete() {
		setUp();
		assertNotNull(storyDao);
		storyDao.delete(story);
		assertThat(storyDao.findAll().size()==0);
	}
	
	@Test
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testFindById () {
		setUp();
		assertNotNull(storyDao);
		TsscStory st = storyDao.findById((long)1);
		assertNotNull(st);
	}
	
	@Test
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testFindAll() {
		
		setUp();
		TsscStory story = new TsscStory();
		story.setAltDescripton("second alt description");
		story.setAltDescShown("second alt description show");
		story.setDescription("second description");
		story.setNumber(new BigDecimal(1));
		story.setInitialSprint(new BigDecimal(1));
		story.setPriority(new BigDecimal(1));
		story.setBusinessValue(new BigDecimal(1));
		assertNotNull(storyDao);
		storyDao.save(story);
		
		assertEquals(2, storyDao.findAll().size());
	}

}
