package com.icesi.taller4.test.delegate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestTemplate;

import com.icesi.taller4.delegate.BussinessScheduledDelegate;
import com.icesi.taller4.model.TsscTimecontrol;

@ExtendWith(SpringExtension.class)
@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
class TimecontrolDelegateTest {
	
	@Mock 
	private RestTemplate restTemplate;
	
	@InjectMocks
	private BussinessScheduledDelegate businessScheduledDelegate;
	
	private TsscTimecontrol scheduled;
	
	@Autowired
	public TimecontrolDelegateTest(BussinessScheduledDelegate TimecontrolDelegate) {
		this.businessScheduledDelegate = TimecontrolDelegate;
	}
	
	@BeforeEach
	public void setUp() {
		scheduled = new TsscTimecontrol();
	}

	@Test
	void testCreateTimecontrol() {
		assertNotNull(businessScheduledDelegate);
		
		when(restTemplate.postForObject("http://localhost:8080/api/timecontrols/0", scheduled, TsscTimecontrol.class)).thenReturn(scheduled);
		
		assertTrue(businessScheduledDelegate.save(scheduled,0)!=null);
	}
	
	@Test
	void testUpdateTimecontrol() {
		assertNotNull(businessScheduledDelegate);
		
		when(restTemplate.postForObject("http://localhost:8080/api/timecontrols/0", scheduled, TsscTimecontrol.class)).thenReturn(scheduled);
		
		assertTrue(businessScheduledDelegate.save(scheduled,0)!=null);
		
		scheduled.setName("Time 1");
		
		businessScheduledDelegate.update(scheduled);
	}
	
	@Test
	void testDeleteTimecontrol() {
		assertNotNull(businessScheduledDelegate);
		
		when(restTemplate.postForObject("http://localhost:8080/api/timecontrols/0", scheduled, TsscTimecontrol.class)).thenReturn(scheduled);
		
		assertTrue(businessScheduledDelegate.save(scheduled,0)!=null);
		
		businessScheduledDelegate.delete(scheduled.getId());
	}
	
	@Test
	void testGetTimecontrol() {
		assertNotNull(businessScheduledDelegate);
		
		when(restTemplate.postForObject("http://localhost:8080/api/timecontrols/0", scheduled, TsscTimecontrol.class)).thenReturn(scheduled);
		
		assertTrue(businessScheduledDelegate.save(scheduled,0)!=null);
		
		when(restTemplate.getForObject("http://localhost:8080/api/timecontrols/"+scheduled.getId(), TsscTimecontrol.class)).thenReturn(scheduled);
		
		assertTrue(businessScheduledDelegate.findById(scheduled.getId())!=null);
	}
	
	@Test
	void testFindAllTimecontrol() {
		assertNotNull(businessScheduledDelegate);
		
		ArrayList<TsscTimecontrol> list  = new ArrayList<TsscTimecontrol>();
		
		list.add(scheduled);
		
		when(restTemplate.postForObject("http://localhost:8080/api/timecontrols/0", scheduled, TsscTimecontrol.class)).thenReturn(scheduled);
		
		assertTrue(businessScheduledDelegate.save(scheduled,0)!=null);
		
		when(restTemplate.getForObject("http://localhost:8080/api/timecontrols", Iterable.class)).thenReturn(list);
		
		assertTrue(((ArrayList<TsscTimecontrol>)businessScheduledDelegate.findAll()).get(0)!=null);
	}

}