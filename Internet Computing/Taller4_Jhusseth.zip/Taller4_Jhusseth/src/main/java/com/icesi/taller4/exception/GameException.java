package com.icesi.taller4.exception;

@SuppressWarnings("serial")
public class GameException  extends Exception {

	public GameException(String msg) {
		super(msg);
	} 
}
