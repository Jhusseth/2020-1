package com.icesi.taller4.exception;

@SuppressWarnings("serial")
public class StoryException extends Exception {
	
	public StoryException(String msg) {
		super(msg);
	}

}
