package com.icesi.taller4;

import java.time.LocalDate;
import java.time.LocalTime;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.thymeleaf.extras.java8time.dialect.Java8TimeDialect;

import com.icesi.taller4.exception.GameException;
import com.icesi.taller4.exception.TopicException;
import com.icesi.taller4.model.TsscAdmin;
import com.icesi.taller4.model.TsscGame;
import com.icesi.taller4.model.TsscTopic;
import com.icesi.taller4.service.AdminService;
import com.icesi.taller4.service.GameService;
import com.icesi.taller4.service.TopicService;


@SpringBootApplication
public class Taller4 {
	
	@Bean
	public Java8TimeDialect java8TimeDialect() {
		return new Java8TimeDialect();
	}

	public static void main(String[] args) throws GameException, TopicException {
		ConfigurableApplicationContext c = SpringApplication.run(Taller4.class, args);
		
		AdminService adminService = c.getBean(AdminService.class);
		TopicService topicService = c.getBean(TopicService.class);
		GameService gameService = c.getBean(GameService.class);
		
		
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		
		TsscAdmin superAdmin = new TsscAdmin();	
		superAdmin.setUser("jhusseth");
		superAdmin.setSuperAdmin("superAdmin");
		superAdmin.setPassword(passwordEncoder.encode("1998"));
		
		TsscAdmin admin = new TsscAdmin();	
		admin.setUser("chapu");
		admin.setSuperAdmin("admin");
		admin.setPassword(passwordEncoder.encode("2000"));
		
		
		adminService.save(admin);
		adminService.save(superAdmin);
		
		
		TsscGame game1 = new TsscGame();
		game1.setScheduledDate(LocalDate.of(2020, 06, 6));
		game1.setScheduledTime(LocalTime.MAX);
		game1.setStartTime(LocalTime.MAX);
		game1.setPauseSeconds((long)3);
		game1.setAdminPassword("123456789");
		game1.setGuestPassword("123456789");
		game1.setUserPassword("123456789");
		game1.setName("firt Game");
		
		
		TsscTopic topic1 = new TsscTopic();
		topic1.setDescription("Este es el tema nuevo");
		topic1.setGroupPrefix("T1");
		topic1.setDefaultGroups(1);
		topic1.setDefaultSprints(2);
		topic1.setName("firt topic");
		
		
		gameService.save(game1);
		topicService.save(topic1);
		
		
	}

}
