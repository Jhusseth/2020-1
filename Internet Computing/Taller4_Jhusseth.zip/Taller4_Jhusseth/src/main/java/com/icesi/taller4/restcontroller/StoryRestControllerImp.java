package com.icesi.taller4.restcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.icesi.taller4.exception.StoryException;
import com.icesi.taller4.model.TsscStory;
import com.icesi.taller4.service.StoryService;

@RestController
@RequestMapping(value = "/api")
public class StoryRestControllerImp implements StoryRestController {
	
	@Autowired
	private StoryService StoryService;
	
	@PostMapping("/stories/{id}")
	@Override
	public TsscStory save(@RequestBody TsscStory Story,@PathVariable("id") long id) throws StoryException {
		return StoryService.save(Story, id);
	}
	
	@PutMapping("/stories")
	@Override
	public TsscStory update(@RequestBody TsscStory Story) throws StoryException {
		return StoryService.update(Story);
	}
	
	@DeleteMapping("/stories/{id}")
	@Override
	public void delete(@PathVariable("id") long id) throws StoryException {
		TsscStory Story = StoryService.findById(id);
		StoryService.delete(Story);
		
	}
	
	@GetMapping("/stories/{id}")
	@Override
	public TsscStory findById(@PathVariable("id") long id) throws StoryException {
		return StoryService.findById(id);
	}
	
	@GetMapping("/stories")
	@Override
	public Iterable<TsscStory> findAll() {
		return StoryService.findAll();
	}

}
