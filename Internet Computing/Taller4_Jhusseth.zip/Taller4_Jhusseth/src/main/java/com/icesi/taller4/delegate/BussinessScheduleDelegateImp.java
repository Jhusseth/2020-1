package com.icesi.taller4.delegate;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.icesi.taller4.model.TsscTimecontrol;

@Component
public class BussinessScheduleDelegateImp implements BussinessScheduledDelegate{

	public static final String LOCAL_URL = "http://localhost:8080/api";
	
	private  RestTemplate restTemplate;
	
	public BussinessScheduleDelegateImp() {
		restTemplate = new RestTemplate();
	}
	
	@Override
	public TsscTimecontrol save(TsscTimecontrol Timecontrol,long id) {
		return restTemplate.postForObject(LOCAL_URL + "/timecontrols/"+id, Timecontrol, TsscTimecontrol.class);
	}

	@Override
	public void update(TsscTimecontrol Timecontrol) {
		restTemplate.put(LOCAL_URL + "/timecontrols", Timecontrol);
	}

	@Override
	public void delete(long id) {
		restTemplate.delete(LOCAL_URL +"/timecontrols/"+id, id);
	}

	@Override
	public TsscTimecontrol findById(long id) {
		return restTemplate.getForObject(LOCAL_URL +"/timecontrols/"+id, TsscTimecontrol.class);
	}

	@SuppressWarnings("unchecked")
	@Override
	public Iterable<TsscTimecontrol> findAll() {
		return restTemplate.getForObject(LOCAL_URL + "/timecontrols", Iterable.class);
	}

}
