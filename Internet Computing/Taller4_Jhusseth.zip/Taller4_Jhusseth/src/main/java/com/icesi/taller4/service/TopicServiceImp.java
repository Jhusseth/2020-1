package com.icesi.taller4.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icesi.taller4.dao.TopicDao;
import com.icesi.taller4.exception.TopicException;
import com.icesi.taller4.model.TsscGame;
import com.icesi.taller4.model.TsscTopic;

@Service
public class TopicServiceImp implements TopicService  {
	@Autowired
	private TopicDao topicDao;
	
	@Override
	public TsscTopic save(TsscTopic topic) throws TopicException {
		if(topic == null) {
			throw new TopicException("CreateTopic: The new topic can be null");
		}else if(topic.getDefaultGroups() <= 0) {
			throw new TopicException("CreateTopic: Number of groups equal or less to 0");
		}else if(topic.getDefaultSprints() <= 0) {
			throw new TopicException("CreateTopic: Number of sptrints equal or less to 0");
		}
		topic.setTsscGames(new ArrayList<TsscGame>());
		return topicDao.save(topic);
	}
	
	@Override
	public TsscTopic update(TsscTopic topic) throws TopicException {
		
		if(topic == null) {
			throw new TopicException("UpdateTopic: The topic to update can be null");
		}else if(topic.getDefaultGroups() <= 0) {
			throw new TopicException("UpdateTopic: Number of groups equal or less to 0");
		}else if(topic.getDefaultSprints() <= 0) {
			throw new TopicException("UpdateTopic: Number of sptrints equal or less to 0");
		}else if(topicDao.findById(topic.getId())==null) {
			throw new TopicException("UpdateTopic: The topic to update dosen't exist.");
		}
		
		return topicDao.update(topic);
	}
	
	@Override
	public void delete(TsscTopic topic) throws TopicException {
		List<TsscGame> list = topic.getTsscGames();
		for (int i = 0; i < list.size(); i++) {
			list.get(i).setTsscTopic(null);
		}
		topic.setTsscGames(null);
		
		
		topicDao.delete(topic);
	}
	
	@Override
	public TsscTopic findById(long id) throws TopicException {
		return topicDao.findById(id);
	}

	@Override
	public Iterable<TsscTopic> findAll() {
		return topicDao.findAll();
	}

}
