package com.icesi.taller4.delegate;

import com.icesi.taller4.model.TsscStory;

public interface BussinessStoryDelegate {

	public TsscStory save(TsscStory Story, long id);
	public void update(TsscStory Story);
	public void delete(long id);
	public TsscStory findById(long id);
	public Iterable<TsscStory> findAll();
}
