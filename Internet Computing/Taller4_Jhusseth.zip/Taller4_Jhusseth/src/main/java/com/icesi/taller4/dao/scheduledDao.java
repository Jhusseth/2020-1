package com.icesi.taller4.dao;

import java.util.List;

import com.icesi.taller4.model.TsscTimecontrol;

public interface scheduledDao {
	public TsscTimecontrol save(TsscTimecontrol entity);
	public TsscTimecontrol update(TsscTimecontrol entity);
	public TsscTimecontrol delete(TsscTimecontrol entity);
	public TsscTimecontrol findById(long codigo);
	public List<TsscTimecontrol> findAll();	

}
