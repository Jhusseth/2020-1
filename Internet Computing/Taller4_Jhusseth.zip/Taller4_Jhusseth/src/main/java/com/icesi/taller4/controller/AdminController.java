package com.icesi.taller4.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.icesi.taller4.delegate.BusinessAdminDelegate;
import com.icesi.taller4.model.TsscAdmin;
import com.icesi.taller4.validations.ValidationGroup1;

@Controller
public class AdminController {
	
	private BusinessAdminDelegate businessAdminDelegate;

	@Autowired
	public AdminController(BusinessAdminDelegate businessAdminDelegate) {
		this.businessAdminDelegate = businessAdminDelegate;
	}
	
	@GetMapping("/login")
	public String log() {
		return "login/login";
	}
	
	@GetMapping("/admins")
	public String admisIndex(Model model) {
		model.addAttribute("admins", businessAdminDelegate.findAll());
		return "/admins/index";
	}
	
	
	@GetMapping("/admins/add")
	public String addAdmins(Model model) {
		model.addAttribute("admin", new TsscAdmin());
		model.addAttribute("types", businessAdminDelegate.getTypes());
		return "admins/add-admin";
	}
	
	@PostMapping("/admins/add")
	public String saveAdmin(@Validated(ValidationGroup1.class) TsscAdmin admin, BindingResult result, @RequestParam(value = "action", required = true) String action) {
	 if (!action.equals("Cancel")) {
		 if(result.hasErrors()) {
			 return "admins/add-admins";
		 } 
		 BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		 String pass = passwordEncoder.encode(admin.getPassword());
		 admin.setPassword(pass);
		 businessAdminDelegate.save(admin);	 
	 }
		 return "redirect:/admins";	
	}
	
	
	@GetMapping("/admins/edit/{id}")
	public String showUpdateFormAdmin(@PathVariable("id") long id, Model model) {
		TsscAdmin admin = businessAdminDelegate.findById(id);
		if (admin == null) {
			throw new IllegalArgumentException("Invalid user Id:" + id);
		}
		model.addAttribute("admin", admin);
		model.addAttribute("types", businessAdminDelegate.getTypes());
		return "admins/update-admin";
	}
	
	@PostMapping("/admins/edit/{id}")
	public String updateAdmin(@Validated(ValidationGroup1.class) TsscAdmin admin,  BindingResult result,@PathVariable("id") long id,
			@RequestParam(value = "action", required = true) String action, Model model) {
		if (action != null && !action.equals("Cancel")) {
			
			if(result.hasErrors()) {
				model.addAttribute("types", businessAdminDelegate.getTypes());
				return "admins/update-admin";
			}
			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
			String pass = passwordEncoder.encode(admin.getPassword());
			admin.setPassword(pass);
			
			businessAdminDelegate.update(admin);
		}
		return "redirect:/admins";
	}
	
	@GetMapping("/admins/del/{id}")
	public String deleteAdmin(@PathVariable("id") long id) {
		businessAdminDelegate.delete(id);
		return "redirect:/admins";
	}
	
	@GetMapping("/access-denied")
	public String access(Model model) {
		
		return "login/access-denied";
	}
}
