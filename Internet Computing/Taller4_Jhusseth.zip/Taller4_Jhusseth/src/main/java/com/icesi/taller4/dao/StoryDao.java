package com.icesi.taller4.dao;

import java.util.List;

import com.icesi.taller4.model.TsscStory;

public interface StoryDao {
	public TsscStory save(TsscStory entity);
	public TsscStory update(TsscStory entity);
	public TsscStory delete(TsscStory entity);
	public TsscStory findById(long codigo);
	public List<TsscStory> findAll();	
}
