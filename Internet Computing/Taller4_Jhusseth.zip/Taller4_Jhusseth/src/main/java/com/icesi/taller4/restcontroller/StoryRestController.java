package com.icesi.taller4.restcontroller;

import com.icesi.taller4.exception.StoryException;
import com.icesi.taller4.model.TsscStory;

public interface StoryRestController {
	public TsscStory save(TsscStory Story, long id) throws StoryException ;
	public TsscStory update(TsscStory Story) throws StoryException;
	public void delete(long id) throws StoryException;
	public TsscStory findById(long id) throws StoryException;
	public Iterable<TsscStory> findAll();

}
