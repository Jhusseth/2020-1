package com.icesi.taller4.controller;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.icesi.taller4.delegate.BussinessGameDelegate;
import com.icesi.taller4.delegate.BussinessTopicDelegate;
import com.icesi.taller4.exception.TopicException;
import com.icesi.taller4.model.TsscTopic;
import com.icesi.taller4.validations.ValidationGroup1;
import com.icesi.taller4.validations.ValidationGroup2;

@Controller
public class TopicController {
	
	private BussinessTopicDelegate topicDelegate;
	
	private BussinessGameDelegate gameDelegate;

	@Autowired
	public TopicController(BussinessTopicDelegate topicDelegate,BussinessGameDelegate gameDelegate) {
		this.topicDelegate = topicDelegate;
		this.gameDelegate = gameDelegate;
	
	}
	
	@GetMapping("/topics")
	public String indexTopic(Model model) {
		model.addAttribute("topics", topicDelegate.findAll());
		return "topics/index";
	}
	
	@GetMapping("/topics/add")
	public String addTopic(Model model) {
		model.addAttribute("tsscTopic", new TsscTopic());
		
		return "topics/add-topic-1";
	}
	
	@PostMapping("/topics/add1")
	public String addTopicStepOne(@Validated(ValidationGroup1.class) @ModelAttribute TsscTopic tsscTopic,BindingResult bindingResult, @RequestParam(value = "action", required = true) String action, Model model) {
		
		if (action.equals("Cancelar")) {
			
			return "redirect:/topics";
		}
		
		if (bindingResult.hasErrors()) {
			model.addAttribute("tsscTopic", new TsscTopic());
			return "topics/add-topic-1";
		} 
	
		
		
		return "topics/add-topic-2";
		
		
	}
	
	@PostMapping("/topics/add2")
	public String addTopicStepTwo(@Validated(ValidationGroup2.class) @ModelAttribute TsscTopic tsscTopic,BindingResult bindingResult, @RequestParam(value = "action", required = true) String action, Model model) throws TopicException {
		
		
		if (action.equals("Cancelar")) {
			
			return "redirect:/topics";
			
		}
		
		if (bindingResult.hasErrors()) {
			
			return "topics/add-topic-2";
		} 
	
		
		topicDelegate.save(tsscTopic);
			
		return "redirect:/topics";
		
		
	}
	
	@GetMapping("/topics/edit/{id}")
	public String editTopic(@PathVariable("id") long id, Model model) throws TopicException {
		TsscTopic tsscTopic = topicDelegate.findById(id);
		if (tsscTopic == null)
			throw new IllegalArgumentException("Invalid topic Id:" + id);
		
		model.addAttribute("tsscTopic", tsscTopic);
		
		return "topic/edit-topic";
	}
	
	@PostMapping("/topics/edit/{id}")
	public String updateTopic(@PathVariable("id") long id,
			@RequestParam(value = "action", required = true) String action, @Validated({ValidationGroup1.class,ValidationGroup2.class} ) @ModelAttribute TsscTopic tsscTopic,BindingResult bindingResult, Model model) throws TopicException {
		
		if (action.equals("Cancelar")) {
			
			return "redirect:/topics";
		}
		
		if (bindingResult.hasErrors()) {

			return "topics/edit-topic";
		}
		
		if (action != null && !action.equals("Cancelar")) {
			topicDelegate.update(tsscTopic);
		}
		return "redirect:/topics";
	}
	
	@GetMapping("/topics/del/{id}")
	public String deleteTopic(@PathVariable("id") long id) throws IllegalArgumentException, TopicException {
		TsscTopic tsscTopic = topicDelegate.findById(id);
		topicDelegate.delete(tsscTopic.getId());
		return "redirect:/topics";
		
	}
	
	
	@GetMapping("/topics/query/date")
	public String query(@RequestParam(value = "Date", required = true) String Date, Model model) {
		if(Date == "") {
			return "redirect:/topics";
		}
		String[] date = Date.split("-");
		LocalDate newDate = LocalDate.of(Integer.parseInt(date[0]), Integer.parseInt(date[1]), Integer.parseInt(date[2]));
		model.addAttribute("topics", gameDelegate.findByScheduledTopics(newDate));
		
		return "topics/index";
		
	}
	
	

	
}
