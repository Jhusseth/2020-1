package com.icesi.taller4.delegate;

import java.util.List;

import com.icesi.taller4.model.TsscAdmin;

public interface BusinessAdminDelegate {
	public TsscAdmin save(TsscAdmin Admin);
	public void update(TsscAdmin Admin);
	public void delete(long id);
	public TsscAdmin findById(long id);
	public Iterable<TsscAdmin> findAll();
	public List<String> getTypes();
}
