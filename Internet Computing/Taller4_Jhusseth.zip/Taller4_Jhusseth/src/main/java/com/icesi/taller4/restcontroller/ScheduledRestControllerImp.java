package com.icesi.taller4.restcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.icesi.taller4.model.TsscTimecontrol;
import com.icesi.taller4.service.ScheduledService;

@RestController
@RequestMapping(value = "/api")
public class ScheduledRestControllerImp implements ScheduledRestController {

	@Autowired
	private ScheduledService TimecontrolService;
	
	
	@PostMapping("/timecontrols/{id}")
	@Override
	public TsscTimecontrol save(@PathVariable("id") long id,@RequestBody TsscTimecontrol Timecontrol){
		return TimecontrolService.save(Timecontrol,id);
	}
	
	@PutMapping("/timecontrols")
	@Override
	public TsscTimecontrol update(@RequestBody TsscTimecontrol Timecontrol){
		return TimecontrolService.update(Timecontrol);
	}
	
	@DeleteMapping("/timecontrols/{id}")
	@Override
	public void delete(@PathVariable("id") long id){
		TsscTimecontrol timecontrol = TimecontrolService.findById(id);
		TimecontrolService.delete(timecontrol);	
	}
	
	@GetMapping("/timecontrols/{id}")
	@Override
	public TsscTimecontrol findById(@PathVariable("id") long id){
		return TimecontrolService.findById(id);
	}
	
	@GetMapping("/timecontrols")
	@Override
	public Iterable<TsscTimecontrol> findAll() {
		return TimecontrolService.findAll();
	}

}
