package com.icesi.taller4.validations;

public interface ValidationGame {

}
