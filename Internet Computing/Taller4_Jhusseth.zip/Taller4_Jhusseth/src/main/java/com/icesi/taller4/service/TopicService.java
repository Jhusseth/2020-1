package com.icesi.taller4.service;
 
import com.icesi.taller4.exception.TopicException;
import com.icesi.taller4.model.TsscTopic;

public interface TopicService {
	public TsscTopic save(TsscTopic topic) throws TopicException ;
	public TsscTopic update(TsscTopic topic) throws TopicException;
	public void delete(TsscTopic topic) throws TopicException;
	public TsscTopic findById(long id) throws TopicException;
	public Iterable<TsscTopic> findAll();
}
