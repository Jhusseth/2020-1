package com.icesi.taller4.delegate;

import java.time.LocalDate;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.icesi.taller4.model.TsscGame;
import com.icesi.taller4.model.TsscTopic;

@Component
@Scope("singleton")
public class BussinessGameDelegateImp implements BussinessGameDelegate{
	
	public static final String LOCAL_URL = "http://localhost:8080/api";

	private  RestTemplate restTemplate;
	
	public BussinessGameDelegateImp() {
		restTemplate = new RestTemplate();
	}
	
	@Override
	public TsscGame save(TsscGame game) {
		restTemplate.postForObject(LOCAL_URL +"/games", game,Boolean.class);
		return game;
	}

	@Override
	public void update(TsscGame game) {
		restTemplate.put(LOCAL_URL +"/games", game);
	}
	
	@Override
	public void updateTopic(TsscTopic topic) {
		restTemplate.put(LOCAL_URL+"/topics", topic);
	}

	@Override
	public void delete(long id) {
		restTemplate.delete(LOCAL_URL + "/games/"+id, id);
	}

	@Override
	public TsscGame findById(long id) {
		return restTemplate.getForObject(LOCAL_URL +"/games/"+id, TsscGame.class);
	}

	@SuppressWarnings("unchecked")
	@Override
	public Iterable<TsscGame> findAll() {
		return restTemplate.getForObject(LOCAL_URL +"/games", Iterable.class);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Iterable<TsscTopic> findByScheduledTopics(LocalDate date) {
		return restTemplate.postForObject(LOCAL_URL + "/games/topics",date, Iterable.class);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Iterable<TsscGame> findByScheduledGames(LocalDate date) {
		return restTemplate.postForObject(LOCAL_URL + "/games/games",date, Iterable.class);
	}
	
}
