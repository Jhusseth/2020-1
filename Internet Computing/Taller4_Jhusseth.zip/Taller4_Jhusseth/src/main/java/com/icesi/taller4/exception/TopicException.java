package com.icesi.taller4.exception;

@SuppressWarnings("serial")
public class TopicException extends Exception {


	public TopicException(String msg) {
		super(msg);
	}

}