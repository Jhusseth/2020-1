package com.icesi.taller4.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.icesi.taller4.model.TsscTopic;

@Repository
public interface TopicRepository extends CrudRepository<TsscTopic, Long> {

}
