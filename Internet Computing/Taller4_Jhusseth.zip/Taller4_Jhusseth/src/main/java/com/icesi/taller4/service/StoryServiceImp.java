package com.icesi.taller4.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icesi.taller4.dao.GameDao;
import com.icesi.taller4.dao.StoryDao;
import com.icesi.taller4.exception.StoryException;
import com.icesi.taller4.model.TsscGame;
import com.icesi.taller4.model.TsscStory;

@Service
public class StoryServiceImp implements StoryService {
	
	@Autowired
	private StoryDao StoryDao;
	@Autowired
	private GameDao GameDao;
	
	@Override
	public TsscStory save(TsscStory story, long id) throws StoryException {
		if(story == null) {
			
			throw new StoryException("CreateStory: The new story can be null");
		}
		
		TsscGame game = GameDao.findById(id);
		
		if(GameDao.findById(id) == null) {
			throw new StoryException("CreateStory: The game of new Story haven't been created ");
		}
		
		story.setTsscGame(game);
		
		
		if(story.getTsscGame() == null) {
			throw new StoryException("CreateStory: The new story need have a game");
		}else if(story.getInitialSprint().intValue() <= 0 || story.getBusinessValue().intValue() <= 0 || story.getPriority().intValue() <= 0) {
			throw new StoryException("CreateStory: The business value, initial sprint or the priority are equal or less to 0");
		}
		
		GameDao.update(game);
		
		return StoryDao.save(story);
	}
	
	@Override
	public TsscStory update(TsscStory story) throws StoryException {
		
		if(story == null) {
			throw new StoryException("UpdateStory: The story to update can be null");
		}else if(StoryDao.findById(story.getId()) == null) {
			throw new StoryException("UpdateStory: The story to update doesn't exist");
		}
		
		story.setTsscGame(StoryDao.findById(story.getId()).getTsscGame());
		if(GameDao.findById(story.getTsscGame().getId()) == null) {
			throw new StoryException("UpdateStory: The game of Story to update haven't been created ");
		}else if(story.getTsscGame() == null) {
			throw new StoryException("UpdateStory: The story to update need have a game");
		}else if(story.getInitialSprint().intValue() <= 0 || story.getBusinessValue().intValue() <= 0 || story.getPriority().intValue() <= 0) {
			throw new StoryException("UpdateStory: The business value, initial sprint or the priority are equal or less to 0");
		}
		
		return StoryDao.update(story);
	}
	
	@Override
	public void delete(TsscStory story) throws StoryException {
		story.setTsscGame(null);
		StoryDao.delete(story);
	}

	@Override
	public TsscStory findById(long id) throws StoryException {
		
		return StoryDao.findById(id);
	}

	@Override
	public Iterable<TsscStory> findAll() {
		return StoryDao.findAll();
	}



}
