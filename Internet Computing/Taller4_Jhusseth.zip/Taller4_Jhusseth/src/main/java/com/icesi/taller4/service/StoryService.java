package com.icesi.taller4.service;

import com.icesi.taller4.exception.StoryException;
import com.icesi.taller4.model.TsscStory;

public interface StoryService {
	public TsscStory save(TsscStory story, long id) throws StoryException;
	public TsscStory update(TsscStory story) throws StoryException;
	public void delete(TsscStory story) throws StoryException;
	public TsscStory findById(long id) throws StoryException;
	public Iterable<TsscStory> findAll();
}
