package com.icesi.taller4.service;

import com.icesi.taller4.model.TsscAdmin;

public interface AdminService {
	public TsscAdmin save(TsscAdmin Admin);
	public TsscAdmin update(TsscAdmin Admin);
	public void delete(TsscAdmin Admin);
	public TsscAdmin findById(long id);
	public Iterable<TsscAdmin> findAll();

}
