package com.icesi.taller4.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.icesi.taller4.delegate.BussinessGameDelegate;
import com.icesi.taller4.delegate.BussinessStoryDelegate;
import com.icesi.taller4.exception.GameException;
import com.icesi.taller4.exception.StoryException;
import com.icesi.taller4.exception.TopicException;
import com.icesi.taller4.model.TsscStory;
import com.icesi.taller4.validations.ValidationGame;
import com.icesi.taller4.validations.ValidationGroup1;
import com.icesi.taller4.validations.ValidationGroup2;

@Controller
public class StoryController {
	
	private BussinessStoryDelegate storyDelegate;
	private BussinessGameDelegate gameDelegate;
	
	private long idGame;
	private boolean isFromGame;
	
	@Autowired
	public StoryController(BussinessStoryDelegate storyDelegate,BussinessGameDelegate gameDelegate) {
		this.storyDelegate = storyDelegate;
		this.gameDelegate = gameDelegate;
	}
	
	@GetMapping("/stories")
	public String indexStory(Model model) {
		model.addAttribute("tsscStories",storyDelegate.findAll());
		isFromGame = false;
		return "stories/index2";
	}
	
	@GetMapping("/stories/{id}")
	public String indexStoryGame(@PathVariable("id") long idGame, Model model) {
		this.idGame = idGame;
		model.addAttribute("tsscStories",gameDelegate.findById(idGame).getTsscStories());
		isFromGame = true;
		return "stories/index1";
	}
	
	@GetMapping("/stories/add")
	public String addStory(Model model) {
		
		if(!isFromGame) {
			model.addAttribute("games",gameDelegate.findAll());
		}
		
		model.addAttribute("tsscStory",new TsscStory());
		
		return (isFromGame)? "stories/add-story-1-1" : "stories/add-story-1-2";
	}
	
	@PostMapping("/stories/add1-1")
	public String addStoryStepOneOne(@Validated(ValidationGroup1.class) @ModelAttribute TsscStory tsscStory,BindingResult bindingResult, @RequestParam(value = "action", required = true) String action, Model model) throws GameException {
		
		if (action.equals("Cancelar")) {
			
			return "redirect:/stories/"+idGame ;
		}
		
		if (bindingResult.hasErrors()) {
			
			return "stories/add-story-1-1";
		} 
		
		model.addAttribute("idGame",idGame);
		
		
		return "stories/add-story-2";
		
		
	}
	
	@PostMapping("/stories/add1-2")
	public String addStoryStepOneTwo(@Validated({ValidationGroup1.class,ValidationGame.class}) @ModelAttribute TsscStory tsscStory,BindingResult bindingResult, @RequestParam(value = "action", required = true) String action, Model model) throws GameException {
		
		if (action.equals("Cancelar")) {
			
			return "redirect:/stories" ;
		}
		
		if (bindingResult.hasErrors()) {
			model.addAttribute("games",gameDelegate.findAll());
			return "stories/add-story-1-2";
		} 
	
		idGame = tsscStory.getTsscGame().getId();	
		model.addAttribute("idGame",idGame);
		
		
		return "stories/add-story-2";
		
		
	}
	
	@PostMapping("/stories/add2")
	public String addStoryStepTwo(@Validated(ValidationGroup2.class) @ModelAttribute TsscStory tsscStory,BindingResult bindingResult, @RequestParam(value = "action", required = true) String action, Model model) throws GameException, StoryException{
		
		
		if (action.equals("Cancelar")) {
			
			return (isFromGame)? "redirect:/games/stories/"+idGame : "redirect:/stories";
			
		}

		if (bindingResult.hasErrors()) {
			
			return "stories/add-story-2";
		} 
		
	
		

		storyDelegate.save(tsscStory,idGame);
		
			
		return (isFromGame)? "redirect:/games/stories/"+idGame : "redirect:/stories" ;
		
		
	}
	
	@GetMapping("/stories/edit/{id}")
	public String editStory(@PathVariable("id") long id, Model model) throws TopicException, StoryException {
		TsscStory tsscStory = storyDelegate.findById(id);
		if (tsscStory == null)
			throw new IllegalArgumentException("Invalid topic Id:" + id);
		
		model.addAttribute("tsscStory", tsscStory);
		
		return "stories/edit-story";
	}
	
	@PostMapping("/stories/edit/{id}")
	public String updateStory(@PathVariable("id") long id,
			@RequestParam(value = "action", required = true) String action, @Validated({ValidationGroup1.class,ValidationGroup2.class} ) @ModelAttribute TsscStory tsscStory,BindingResult bindingResult, Model model) throws TopicException, StoryException {
		
		
		if (action.equals("Cancelar")) {
			
			return (isFromGame)? "redirect:/games/stories/"+idGame : "redirect:/stories";
			
		}
		
		if (bindingResult.hasErrors()) {

			return "stories/edit-story";
		}
		
		if (action != null && !action.equals("Cancelar")) {
	
			storyDelegate.update(tsscStory);
		}
		return (isFromGame)? "redirect:/games/stories/"+idGame:"redirect:/stories";
	}
	
	@GetMapping("/stories/del/{id}")
	public String deleteStory(@PathVariable("id") long id) throws IllegalArgumentException, GameException, StoryException {
		TsscStory tsscStory= storyDelegate.findById(id);
		storyDelegate.delete(tsscStory.getId());
		
		return (isFromGame)? "redirect:/games/stories/"+idGame:"redirect:/stories";
		
	}
}
