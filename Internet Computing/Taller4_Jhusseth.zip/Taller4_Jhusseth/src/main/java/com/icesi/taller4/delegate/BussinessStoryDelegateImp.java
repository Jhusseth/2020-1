package com.icesi.taller4.delegate;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.icesi.taller4.model.TsscStory;

@Component
public class BussinessStoryDelegateImp implements BussinessStoryDelegate{

	public static final String LOCAL_URL = "http://localhost:8080/api";
	
	private  RestTemplate restTemplate;
	
	public BussinessStoryDelegateImp() {
		restTemplate = new RestTemplate();
	}
	
	@Override
	public TsscStory save(TsscStory Story, long gameId) {
		return restTemplate.postForObject(LOCAL_URL +"/stories/"+gameId, Story, TsscStory.class);
	}

	@Override
	public void update(TsscStory Story) {
		restTemplate.put(LOCAL_URL +"/stories", Story);
	}

	@Override
	public void delete(long id) {
		restTemplate.delete(LOCAL_URL +"/stories/"+id, id);
	}

	@Override
	public TsscStory findById(long id) {
		return restTemplate.getForObject(LOCAL_URL + "/stories/"+id, TsscStory.class);
	}

	@SuppressWarnings("unchecked")
	@Override
	public Iterable<TsscStory> findAll() {
		return restTemplate.getForObject(LOCAL_URL + "/stories", Iterable.class);
	}
	
	

}
