package com.icesi.taller4.delegate;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.icesi.taller4.model.TsscAdmin;

@Component
public class BusinessAdminDelegateImp implements BusinessAdminDelegate {
	
	public static final String LOCAL_URL = "http://localhost:8080/api";
	
	private  RestTemplate restTemplate;
	
	public BusinessAdminDelegateImp() {
		restTemplate = new RestTemplate();
	}
	
	@Override
	public TsscAdmin save(TsscAdmin Admin) {
		return restTemplate.postForObject(LOCAL_URL+ "/admins", Admin, TsscAdmin.class);
	}

	@Override
	public void update(TsscAdmin admin) {
		restTemplate.put(LOCAL_URL +"/admins", admin);
	}

	@Override
	public void delete(long id) {
		restTemplate.delete(LOCAL_URL+"/admins/"+id,id);
		
	}

	@Override
	public TsscAdmin findById(long id) {
		return restTemplate.getForObject(LOCAL_URL + "/admins/"+id, TsscAdmin.class);
	}

	@SuppressWarnings("unchecked")
	@Override
	public Iterable<TsscAdmin> findAll() {
		return restTemplate.getForObject(LOCAL_URL + "/admins", Iterable.class);
	}
	
	@Override
	public List<String> getTypes(){ 

		List<String> list = new ArrayList<>();
		list.add("admin");
		list.add("superAdmin");
		return list;
	}

}
