package com.icesi.taller4.restcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.icesi.taller4.model.TsscAdmin;
import com.icesi.taller4.service.AdminService;

@RestController
@RequestMapping(value = "/api")
public class AdminRestControllerImp implements AdminRestController {
	@Autowired
	private AdminService AdminService;
	
	@PostMapping("/admins")
	@Override
	public TsscAdmin save(@RequestBody TsscAdmin Admin){
		return AdminService.save(Admin);
	}
	
	@PutMapping("/admins")
	@Override
	public TsscAdmin update(@RequestBody TsscAdmin admin){
		return AdminService.update(admin);
	}
	
	@DeleteMapping("/admins/{id}")
	@Override
	public void delete(@PathVariable("id") long id){
		TsscAdmin Admin = AdminService.findById(id);
		AdminService.delete(Admin);
		
	}
	
	@GetMapping("/admins/{id}")
	@Override
	public TsscAdmin findById(@PathVariable("id") long id){
		return AdminService.findById(id);
	}
	
	@GetMapping("/admins")
	@Override
	public Iterable<TsscAdmin> findAll() {
		return AdminService.findAll();
	}
}
