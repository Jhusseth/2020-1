package com.icesi.taller4.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.icesi.taller4.dao.AdminDao;
import com.icesi.taller4.model.TsscAdmin;

@Service
public class AdminServiceImp implements AdminService{
	
	@Autowired
	private AdminDao AdminDao;

	@Override
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public TsscAdmin save(TsscAdmin Admin) {
		return AdminDao.save(Admin);
	}
	
	@Override
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public TsscAdmin update(TsscAdmin Admin) {
		return AdminDao.update(Admin);
	}
	
	@Override
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void delete(TsscAdmin Admin) {
		AdminDao.delete(Admin);
	}
	
	@Override
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public TsscAdmin findById(long id) {
		return AdminDao.findById(id);
	}
	
	@Override
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public Iterable<TsscAdmin> findAll(){
		return AdminDao.findAll();
	}

}
