package com.icesi.taller4.delegate;

import com.icesi.taller4.model.TsscTimecontrol;

public interface BussinessScheduledDelegate {

	public TsscTimecontrol save(TsscTimecontrol Timecontrol, long id);
	public void update(TsscTimecontrol Timecontrol);
	public void delete(long id);
	public TsscTimecontrol findById(long id);
	public Iterable<TsscTimecontrol> findAll();
}
