package com.icesi.taller4.restcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.icesi.taller4.exception.TopicException;
import com.icesi.taller4.model.TsscTopic;
import com.icesi.taller4.service.TopicService;

@RestController
@RequestMapping(value = "/api")
public class TopicRestControllerImp implements TopicRestController {
	
	@Autowired
	private TopicService TopicService;
	
	@PostMapping("/topics")
	@Override
	public TsscTopic save(@RequestBody TsscTopic topic) throws TopicException {
		return TopicService.save(topic);
	}
	
	@PutMapping("/topics")
	@Override
	public TsscTopic update(@RequestBody TsscTopic topic) throws TopicException {
		return TopicService.update(topic);
	}
	
	@DeleteMapping("/topics/{id}")
	@Override
	public void delete(@PathVariable("id") long id) throws TopicException {
		TsscTopic topic = TopicService.findById(id);
		TopicService.delete(topic);
		
	}
	
	@GetMapping("/topics/{id}")
	@Override
	public TsscTopic findById(@PathVariable("id") long id) throws TopicException {
		return TopicService.findById(id);
	}
	
	@GetMapping("/topics")
	@Override
	public Iterable<TsscTopic> findAll() {
		return TopicService.findAll();
	}
	
	
	

}
