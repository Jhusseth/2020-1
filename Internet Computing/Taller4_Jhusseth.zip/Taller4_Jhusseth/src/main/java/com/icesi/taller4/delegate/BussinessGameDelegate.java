package com.icesi.taller4.delegate;

import java.time.LocalDate;

import com.icesi.taller4.model.TsscGame;
import com.icesi.taller4.model.TsscTopic;

public interface BussinessGameDelegate {

	public TsscGame save(TsscGame game);
	public void update(TsscGame game);
	public void updateTopic(TsscTopic game);
	public void delete(long id);
	public TsscGame findById(long id);
	public Iterable<TsscGame> findAll();
	public Iterable<TsscTopic> findByScheduledTopics(LocalDate date);
	public Iterable<TsscGame> findByScheduledGames(LocalDate date);
}
