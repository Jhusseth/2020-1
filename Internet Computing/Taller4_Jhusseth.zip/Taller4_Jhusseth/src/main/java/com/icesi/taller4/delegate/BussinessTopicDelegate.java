package com.icesi.taller4.delegate;

import com.icesi.taller4.model.TsscTopic;

public interface BussinessTopicDelegate {

	public TsscTopic save(TsscTopic Topic);
	public void update(TsscTopic Topic);
	public void delete(long id);
	public TsscTopic findById(long id);
	public Iterable<TsscTopic> findAll();
}
