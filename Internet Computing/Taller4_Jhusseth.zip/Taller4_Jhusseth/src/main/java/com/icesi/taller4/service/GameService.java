package com.icesi.taller4.service;

import java.time.LocalDate;

import com.icesi.taller4.exception.GameException;
import com.icesi.taller4.model.TsscGame;
import com.icesi.taller4.model.TsscTopic;

public interface GameService {
	public boolean save(Object game) throws GameException;
	public boolean update(Object game) throws GameException;
	public void delete(TsscGame game) throws GameException;
	public TsscGame findById(long id) throws GameException;
	public Iterable<TsscGame> findAll();
	public Iterable<TsscTopic> findAllTopics();
	public void updateTopic(TsscTopic topic);
	public Iterable<TsscTopic> findByScheduledTopics(LocalDate date);
	public Iterable<TsscGame> findByScheduledGames(LocalDate date);
	
}
