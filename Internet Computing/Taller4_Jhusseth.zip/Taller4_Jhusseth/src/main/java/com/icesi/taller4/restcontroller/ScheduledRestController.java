package com.icesi.taller4.restcontroller;

import com.icesi.taller4.model.TsscTimecontrol;

public interface ScheduledRestController {
	public TsscTimecontrol save(long id,TsscTimecontrol timecontrol );
	public TsscTimecontrol update(TsscTimecontrol timecontrol );
	public void delete(long id);
	public TsscTimecontrol findById(long id);
	public Iterable<TsscTimecontrol> findAll();

}
