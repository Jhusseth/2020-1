package com.icesi.taller4.delegate;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.icesi.taller4.model.TsscTopic;

@Component
@Scope("singleton")
public class BussinessTopicDelegateImp implements BussinessTopicDelegate{
	
	public static final String LOCAL_URL = "http://localhost:8080/api";
	
	private  RestTemplate restTemplate;
	
	public BussinessTopicDelegateImp() {
		restTemplate = new RestTemplate();
	}
	
	@Override
	public TsscTopic save(TsscTopic Topic) {
		return restTemplate.postForObject(LOCAL_URL +"/topics", Topic, TsscTopic.class);
	}

	@Override
	public void update(TsscTopic Topic) {
		restTemplate.put(LOCAL_URL +"/topics", Topic);
	}

	@Override
	public void delete(long id) {
		restTemplate.delete(LOCAL_URL + "/topics/"+id, id);
	}

	@Override
	public TsscTopic findById(long id) {
		return restTemplate.getForObject(LOCAL_URL + "/topics/"+id, TsscTopic.class);
	}

	@SuppressWarnings("unchecked")
	@Override
	public Iterable<TsscTopic> findAll() {
		return restTemplate.getForObject(LOCAL_URL + "/topics", Iterable.class);
	}

}
