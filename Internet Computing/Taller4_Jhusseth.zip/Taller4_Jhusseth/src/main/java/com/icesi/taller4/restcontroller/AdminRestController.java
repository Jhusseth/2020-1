package com.icesi.taller4.restcontroller;

import com.icesi.taller4.model.TsscAdmin;

public interface AdminRestController {
	public TsscAdmin save(TsscAdmin Admin);
	public TsscAdmin update(TsscAdmin Admin);
	public void delete(long id);
	public TsscAdmin findById(long id);
	public Iterable<TsscAdmin> findAll();

}
