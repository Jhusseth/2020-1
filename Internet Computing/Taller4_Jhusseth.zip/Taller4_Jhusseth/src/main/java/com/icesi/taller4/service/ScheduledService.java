package com.icesi.taller4.service;

import com.icesi.taller4.model.TsscTimecontrol;

public interface ScheduledService {
	public TsscTimecontrol save(TsscTimecontrol timecontrol,long id );
	public TsscTimecontrol update(TsscTimecontrol timecontrol );
	public void delete(TsscTimecontrol timecontrol);
	public TsscTimecontrol findById(long id);
	public Iterable<TsscTimecontrol> findAll();

}
