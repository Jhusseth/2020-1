package com.icesi.taller4.repository;

import org.springframework.data.repository.CrudRepository;

import com.icesi.taller4.model.TsscAdmin;

public interface AdminRepository extends CrudRepository<TsscAdmin, Long> {
	
	TsscAdmin findByUser(String user);

}
