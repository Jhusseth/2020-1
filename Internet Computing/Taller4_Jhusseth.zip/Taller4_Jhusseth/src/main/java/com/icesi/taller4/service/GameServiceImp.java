package com.icesi.taller4.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icesi.taller4.dao.GameDao;
import com.icesi.taller4.dao.StoryDao;
import com.icesi.taller4.dao.TopicDao;
import com.icesi.taller4.exception.GameException;
import com.icesi.taller4.model.TsscGame;
import com.icesi.taller4.model.TsscStory;
import com.icesi.taller4.model.TsscTimecontrol;
import com.icesi.taller4.model.TsscTopic;

@Service
public class GameServiceImp implements GameService {
	@Autowired
	private GameDao GameDao;
	@Autowired
	private TopicDao TopicDao;
	@Autowired
	private StoryDao StoryDao;
	
	@Override
	public boolean save(Object game) throws GameException {
		if (game == null) {
			throw new GameException("CreateGame: The new game or topic can be null");
		} if (game instanceof TsscGame ) {
			if(((TsscGame) game).getNGroups() <= 0) {
				throw new GameException("CreateGame: Number of groups equal or less to 0");
			}else if(((TsscGame) game).getNSprints() <= 0) {
				throw new GameException("CreateGame: Number of sptrints equal or less to 0");
			}
			GameDao.save((TsscGame) game);
			
			return true ;
		}else if(game instanceof TsscTopic) {
			if(TopicDao.findById(((TsscTopic) game).getId()) == null) {
				throw new GameException("CreateGame: The topic to add dosen't exist.");
			}
			TsscGame newGame = new TsscGame();
			
			ArrayList<TsscStory> listStories = new ArrayList<>();
			listStories.addAll(((TsscTopic) game).getTsscStories());
			
			ArrayList<TsscTimecontrol> listTimecontrol = new ArrayList<>();
			listTimecontrol.addAll(((TsscTopic) game).getTsscTimeControl());
			
			newGame.setTsscStories(listStories);
			newGame.setTsscTimecontrol(listTimecontrol);
			
			GameDao.save(newGame);
			
			((TsscTopic) game).getTsscGames().add(newGame);
			
		
			TopicDao.update((TsscTopic) game);
				
			return true;
		}
		
		return false;
	}
	
	@Override
	public boolean update(Object game) throws GameException {
		if (game == null) {
			throw new GameException("UpdateGame: The new game or topic can be null");
		} if (game instanceof TsscGame ) {
			if(GameDao.findById(((TsscGame) game).getId()) == null) {
				throw new GameException("UpdateGame: The game to update dosen't exist");
			}else if(((TsscGame) game).getNGroups() <= 0) {
				throw new GameException("UpdateGame: Number of groups equal or less to 0");
			}else if(((TsscGame) game).getNSprints() <= 0) {
				throw new GameException("UpdateGame: Number of sptrints equal or less to 0");
			}				
			
			
			GameDao.update((TsscGame) game);
			
			
			return true;
			
		}else if(game instanceof TsscTopic) {
			
			if(TopicDao.findById(((TsscTopic) game).getId())==null) {
				throw new GameException("UpdateGame: The topic to update dosen't exist.");
			}
			
		
				
			
			TopicDao.update((TsscTopic) game);
				
			return true;
		}
		
		return false;
	}
	@Override
	public void delete(TsscGame game) throws GameException {
		List<TsscStory> stories = game.getTsscStories();
		List<TsscTimecontrol> timecontrols = game.getTsscTimecontrols();
		
		for (int i = 0; i < stories.size(); i++) {
			if(stories.size()!=0) {
				
				stories.get(i).setTsscGame(null);
				StoryDao.delete(stories.get(i));
				
			}
	
		}
		
		for (int i = 0; i < timecontrols.size(); i++) {

			if(timecontrols.size()!=0) {
				
				timecontrols.get(i).setTsscGame(null);
			}
		}
		GameDao.delete(game);
	}
	
	@Override
	public TsscGame findById(long id) throws GameException {
		return GameDao.findById(id);
	}

	@Override
	public Iterable<TsscGame> findAll() {
		return GameDao.findAll();
	}

	@Override
	public Iterable<TsscTopic>  findAllTopics() {		
		return TopicDao.findAll();
	}

	@Override
	public void updateTopic(TsscTopic topic) {
		TopicDao.save(topic);
		
		
	}
	
	@Override
	public Iterable<TsscTopic> findByScheduledTopics(LocalDate date){
		return GameDao.Query2A(date);
	}
	
	@Override
	public Iterable<TsscGame> findByScheduledGames(LocalDate date){
		return GameDao.Query2B(date);
	}

	

}
