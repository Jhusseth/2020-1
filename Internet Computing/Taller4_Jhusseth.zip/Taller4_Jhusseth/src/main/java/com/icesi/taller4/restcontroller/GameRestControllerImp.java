package com.icesi.taller4.restcontroller;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.icesi.taller4.exception.GameException;
import com.icesi.taller4.model.TsscGame;
import com.icesi.taller4.model.TsscTopic;
import com.icesi.taller4.service.GameService;

@RestController
@RequestMapping(value = "/api")
public class GameRestControllerImp implements GameRestController {
	@Autowired
	private GameService GameService;
	
	@PostMapping("/games")
	@Override
	public Boolean save(@RequestBody TsscGame Game) throws GameException {
		return GameService.save(Game);
	}
	
	@PutMapping("/games")
	@Override
	public boolean update(@RequestBody TsscGame Game) throws GameException {
		return GameService.update(Game);
	}
	
	@DeleteMapping("/games/{id}")
	@Override
	public void delete(@PathVariable("id") long id) throws GameException {
		TsscGame Game = GameService.findById(id);
		GameService.delete(Game);
		
	}
	
	@GetMapping("/games/{id}")
	@Override
	public TsscGame findById(@PathVariable("id") long id) throws GameException {
		return GameService.findById(id);
	}
	
	@GetMapping("/games")
	@Override
	public Iterable<TsscGame> findAll() {
		return GameService.findAll();
	}
	
	@PostMapping("/games/topics")
	@Override
	public Iterable<TsscTopic> findByScheduledTopics(@RequestBody LocalDate date) {
		return GameService.findByScheduledTopics(date);
	}
	
	@PostMapping("/games/games")
	@Override
	public Iterable<TsscGame> findByScheduledGames(@RequestBody LocalDate date) {
		return GameService.findByScheduledGames(date);
	}

}
