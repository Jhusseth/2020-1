package com.icesi.taller4.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.icesi.taller4.delegate.BussinessGameDelegate;
import com.icesi.taller4.delegate.BussinessScheduledDelegate;
import com.icesi.taller4.model.TsscTimecontrol;
import com.icesi.taller4.validations.ValidationGroup1;

@Controller
public class ScheduledController {
	private BussinessScheduledDelegate timecontrolDelegate;
	private BussinessGameDelegate gameDelegate;
	
	private long idGame;
	
	
	@Autowired
	public ScheduledController(BussinessScheduledDelegate timecontrolDelegate,BussinessGameDelegate gameDelegate) {
		this.timecontrolDelegate = timecontrolDelegate;
		this.gameDelegate = gameDelegate;
	}
	
	@GetMapping("/timecontrols/{id}")
	public String indexTimecontrol(@PathVariable("id") long idGame, Model model) {
		this.idGame = idGame;

		model.addAttribute("tsscTimecontrols",gameDelegate.findById(idGame).getTsscTimecontrols());
		return "timecontrols/index";
	}
	
	@GetMapping("/timecontrols/add")
	public String addTimecontrol(Model model) {
		model.addAttribute("tsscTimecontrol", new TsscTimecontrol());
		return "timecontrols/add-timecontrol";
	}
	
	@PostMapping("/timecontrols/add")
	public String addTimecontrolOne(@Validated(ValidationGroup1.class) @ModelAttribute TsscTimecontrol tsscTimecontrol,BindingResult bindingResult, @RequestParam(value = "action", required = true) String action, Model model) {
		
		if (action.equals("Cancelar")) {
			
			return "redirect:/games/timecontrol/"+idGame;
			
		}
		
		if (bindingResult.hasErrors()) {
			
			return "timecontrols/add-timecontrol";
		} 
		
		timecontrolDelegate.save(tsscTimecontrol,idGame);
		
		return "redirect:/games/timecontrol/"+idGame;
	}
	
	@GetMapping("/timecontrols/edit/{id}")
	public String updateTimecontrol(@PathVariable("id") long id, Model model) {
		TsscTimecontrol tsscTimecontrol = timecontrolDelegate.findById(id);
		if (tsscTimecontrol == null)
			throw new IllegalArgumentException("Invalid timecontrol Id:" + id);
		
		model.addAttribute("tsscTimecontrol", tsscTimecontrol);
		return "timecontrols/edit-timecontrol";
	}
	
	@PostMapping("/timecontrols/edit/{id}")
	public String updateTimecontrolOne(@PathVariable("id") long id,
			@RequestParam(value = "action", required = true) String action, @Validated(ValidationGroup1.class) @ModelAttribute TsscTimecontrol tsscTimecontrol,BindingResult bindingResult, Model model) {
		
		if (action.equals("Cancelar")) {
			
			return "redirect:/games/timecontrol/"+idGame;
			
		}
		
		if (bindingResult.hasErrors()) {
			
			return "timecontrols/edit-timecontrol";
		}
		
		if (action != null) {
			timecontrolDelegate.update(tsscTimecontrol);
		}
		
		
		return "redirect:/games/timecontrol/"+idGame;
	}
	
	@GetMapping("/timecontrols/del/{id}")
	public String deleteTimecontrol(@PathVariable("id") long id) {
		timecontrolDelegate.delete(id);
		return "redirect:/timecontrols/"+idGame;
	}

}
