package com.icesi.taller4.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.icesi.taller4.model.TsscSprint;

@Repository
public interface SprintRepository extends CrudRepository<TsscSprint, Long> {

}
