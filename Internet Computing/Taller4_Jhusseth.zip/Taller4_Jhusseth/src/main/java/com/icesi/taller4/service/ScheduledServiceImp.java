package com.icesi.taller4.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.icesi.taller4.dao.GameDao;
import com.icesi.taller4.dao.scheduledDao;
import com.icesi.taller4.model.TsscGame;
import com.icesi.taller4.model.TsscTimecontrol;

@Service
public class ScheduledServiceImp implements ScheduledService {
	@Autowired
	private scheduledDao timecontrolDao;
	
	@Autowired
	private GameDao gameDao;

	@Override
	public TsscTimecontrol save(TsscTimecontrol timecontrol, long id) {
		TsscGame game  = gameDao.findById(id);
		timecontrol.setTsscGame(game);
		//game.addTsscTimecontrol(timecontrol);
		gameDao.update(game);
		return timecontrolDao.save(timecontrol);
	}
	
	@Override
	public TsscTimecontrol update(TsscTimecontrol timecontrol) {
		timecontrol.setTsscGame(timecontrolDao.findById(timecontrol.getId()).getTsscGame());
		return timecontrolDao.update(timecontrol);
	}
	
	@Override
	public void delete(TsscTimecontrol timecontrol) {
		timecontrolDao.delete(timecontrol);
	}

	@Override
	public TsscTimecontrol findById(long id) {
		return timecontrolDao.findById(id);
	}
	
	@Override
	public Iterable<TsscTimecontrol> findAll(){
		return timecontrolDao.findAll();
	}

}
