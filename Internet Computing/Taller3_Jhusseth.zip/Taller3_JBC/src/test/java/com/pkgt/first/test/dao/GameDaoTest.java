package com.pkgt.first.test.dao;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.pkgt.first.project.model.TsscGame;
import com.pkgt.first.project.model.TsscTopic;
import com.pkgt.first.project.repository.GameDao;
import com.pkgt.first.project.repository.StoryDao;
import com.pkgt.first.project.repository.TimeControlDao;
import com.pkgt.first.project.repository.TopicDao;

@ExtendWith(SpringExtension.class)
@ContextConfiguration("/applicationContext.xml")
@Rollback(false)
@TestInstance(Lifecycle.PER_METHOD)
public class GameDaoTest {
	
	@Autowired
	private GameDao gameDao;
	@Autowired
	private TopicDao topicDao;
	@Autowired
	private TimeControlDao timeControlDao;
	@Autowired
	private StoryDao storyDao;
	
	private TsscGame game;
	
	private TsscTopic topic;
	
	
	public void setUp() {
		game = new TsscGame();
		game.setAdminPassword("adminPassword");
		game.setGuestPassword("guestPassword");
		game.setNGroups(5);
		game.setNSprints(4);
		game.setName("game 1");
		game.setPauseSeconds((long)2);
		game.setScheduledDate(LocalDate.of(2020,06,10));
		game.setScheduledTime(LocalTime.of(12, 30));
		game.setStartTime(LocalTime.now());
		game.setTypegameId(new BigDecimal(10));
		game.setUserPassword("userPassword");
		
		gameDao.save(game);
	}
	
	public void setUpTopic() {
		setUp();
		TsscTopic topic = new TsscTopic();
		topic.setName("topic 1");
		topic.setDescription("first topic descriptiion");
		topic.setGroupPrefix("first prefix group");
		game.setTsscTopic(topic);
		topicDao.save(topic);
	}
	
	@Test
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testSaveGame() {
		
		TsscGame game = new TsscGame();
		game.setAdminPassword("adminPassword");
		game.setGuestPassword("guestPassword");
		game.setNGroups(5);
		game.setNSprints(4);
		game.setName("game 1");
		game.setPauseSeconds((long)2);
		game.setScheduledDate(LocalDate.of(2020,06,10));
		game.setScheduledTime(LocalTime.of(12, 30));
		game.setStartTime(LocalTime.now());
		game.setTypegameId(new BigDecimal(10));
		game.setUserPassword("userPassword");
		
		assertNotNull(gameDao);
		
		try {
			gameDao.save(game);
		}
		catch(Exception e) {
			fail(e.getMessage());
		}
		
	}
	
	@Test
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testUpdateGame() {
		
		setUp();
		
		game.setAdminPassword("adminPassword2");
		game.setGuestPassword("guestPassword2");
		game.setNGroups(5);
		game.setNSprints(4);
		game.setName("game 2");
		game.setPauseSeconds((long)2);
		game.setScheduledDate(LocalDate.of(2020,06,20));
		game.setScheduledTime(LocalTime.of(12, 30));
		game.setStartTime(LocalTime.now());
		game.setTypegameId(new BigDecimal(10));
		game.setUserPassword("userPassword2");
		
		assertNotNull(gameDao);
		gameDao.update(game);
		
		assertEquals(game.getName(), "game 2");
		
	}
	
	@Test
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testDeleteGame() {
		
		setUp();
		assertNotNull(gameDao);
		gameDao.delete(game);
		assertThat(gameDao.findAll().size()==0);
		
	}
	
	@Test
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testFindByIdGame() {
		
		setUp();
		assertNotNull(gameDao);
		TsscGame gm = gameDao.findById((long) 1).get();
		assertNotNull(gm);
		
	}
	
	@Test
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testFindByTsscTopicIdGame() {
		setUpTopic();
		assertNotNull(gameDao);
		assertNotNull(topicDao);
		
		List<TsscGame> gm = gameDao.findByTsscTopicId((long) 1);
		
		assertThat(gm.size()>=1);
		
		if(gm.size()>0) {
			assertNotNull(gm);
			TsscGame result = gm.get(0);
			assertEquals(result.getName(), "game 1");
			assertEquals(result.getScheduledDate(), LocalDate.of(2020,06,10));
		}
		
	}
	
	@Test
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testFindByTsscTopicNameGame() {
		setUpTopic();
		assertNotNull(gameDao);
		assertNotNull(topicDao);
		
		List<TsscGame> gm = gameDao.findByTsscTopicName("topic 1");
		
		assertThat(gm.size()>=1);
		
		if(gm.size()>0) {
			assertNotNull(gm);
			TsscGame result = gm.get(0);
			assertEquals(result.getName(), "game 1");
			assertEquals(result.getScheduledDate(), LocalDate.of(2020,06,10));
		}
	}
	
	@Test
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testFindByTsscTopicDescriptionGame() {
		setUpTopic();
		assertNotNull(gameDao);
		assertNotNull(topicDao);
		
		List<TsscGame> gm = gameDao.findByTsscTopicDescription("first topic descriptiion");
		
		assertThat(gm.size()>=1);
		
		if(gm.size()>0) {
			assertNotNull(gm);
			TsscGame result = gm.get(0);
			assertEquals(result.getName(), "game 1");
			assertEquals(result.getScheduledDate(), LocalDate.of(2020,06,10));
		}
	}
	
	@Test
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testFindByScheduledDateAndScheduledDate() {
		setUp();
		assertNotNull(gameDao);
		List<TsscGame> gm = gameDao.findByScheduledDateAndScheduledDate(LocalDate.of(2020,06,05).toString(), LocalDate.of(2020,06,10).toString());
		
		assertThat(gm.size()>=1);
		
		if(gm.size()>0) {
			assertNotNull(gm);
			TsscGame result = gm.get(0);
			assertEquals(result.getName(), "game 1");
			
		}
	}
	
	@Test
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testFindByScheduledDateAndScheduledTime() {
		setUp();
		assertNotNull(gameDao);
		
		List<TsscGame> gm = gameDao.findByScheduledDateAndScheduledTime(LocalDate.of(2020,06,10).toString(), LocalTime.of(12, 30).toString(), LocalTime.of(15, 30).toString());
		
		assertThat(gm.size()>=1);
		
		if(gm.size()>0) {
			assertNotNull(gm);
			TsscGame result = gm.get(0);
			assertEquals(result.getName(), "game 1");
		}
	}
	
	

}
