package com.pkgt.first.test.dao;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.pkgt.first.project.model.AdminType;
import com.pkgt.first.project.model.TsscAdmin;
import com.pkgt.first.project.repository.AdminDao;


@ExtendWith(SpringExtension.class)
@ContextConfiguration("/applicationContext.xml")
@Rollback(false)
@TestInstance(Lifecycle.PER_METHOD)
public class AdminDaoTest {
	
	@Autowired
	private AdminDao adminDao;
	
	private TsscAdmin admin;
	
	private BCryptPasswordEncoder passwordEncoder;
	
	@BeforeEach
	public void setUp() {
		for (TsscAdmin tOption : adminDao.findAll()) {
			adminDao.delete(tOption);
		}
		
		passwordEncoder = new BCryptPasswordEncoder();
		
		TsscAdmin superAdmin = new TsscAdmin();	
		superAdmin.setUser("jhusseth");
		superAdmin.setType(AdminType.superAdmin);
		admin.setSuperAdmin("superAdmin");
		superAdmin.setPassword(passwordEncoder.encode("1998"));
		adminDao.save(admin);
		
	}
	
	@Test
	@DisplayName("Saves a new user with admin rol")
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testSaveAdmin() {
		assertNotNull(adminDao);
		TsscAdmin admin = new TsscAdmin();
		admin.setUser("admin1");
		admin.setType(AdminType.superAdmin);
		admin.setSuperAdmin("superAdmin");
		admin.setPassword(passwordEncoder.encode("123"));
		adminDao.save(admin);
		assertNotNull(adminDao.findById(admin.getId()));
		assertEquals(admin, adminDao.findByUser(admin.getUser()));
		
		
		
	}
	
	@Test
	@DisplayName("Update an admin user already in the system")
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testUpdate() {
		
		assertNotNull(adminDao);
		
		admin.setUser("admin2");
		admin.setType(AdminType.admin);
		admin.setSuperAdmin("admin");
		admin.setPassword(passwordEncoder.encode("1234"));
		
		adminDao.update(admin);
		
		assertEquals(admin.getUser(), adminDao.findByUser(admin.getUser()).getUser());
		
	}
	
	@Test
	@DisplayName("Delete an user already in the system")
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testDelete() {
		assertNotNull(adminDao);
		adminDao.delete(admin);
		assertFalse(adminDao.findById(admin.getId())!=null);
	}
	
	@Test
	@DisplayName("Find an user (admin) by the id")
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testFindById () {
		assertNotNull(adminDao);
		TsscAdmin ad = adminDao.findById((long)1);
		assertNotNull(ad);
	}
	
	@Test
	@DisplayName("Find all the users (admin) in the list")
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void testFindAll() {	
		assertNotNull(adminDao);
		List<TsscAdmin> admins =  adminDao.findAll();
		assertEquals(1, admins.size());
		assertEquals(admin.getUser(), admins.get(0).getUser());	
	}
	
	@Test
	@DisplayName("Find an user (admin) of the system")
	@Transactional(readOnly=true, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void findByUser() {
		
		assertNotNull(adminDao);
		assertNotNull(adminDao.findByUser(admin.getUser()));
		assertEquals(admin.getSuperAdmin(), adminDao.findByUser(admin.getUser()).getSuperAdmin());
		
	}
	
	

}
