package com.pkgt.first.test.unit;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

import com.pkgt.first.project.model.TsscGame;
import com.pkgt.first.project.model.TsscStory;
import com.pkgt.first.project.model.TsscTopic;
import com.pkgt.first.project.repository.GameDao;
import com.pkgt.first.project.repository.StoryDao;
import com.pkgt.first.project.repository.TopicDao;
import com.pkgt.first.project.service.GameService;
import com.pkgt.first.project.service.StoryService;
import com.pkgt.first.project.service.TopicService;



@SpringBootTest
@ContextConfiguration(classes = SaveGameDUnitTest.class)
@TestInstance(Lifecycle.PER_METHOD)
class SaveGameDUnitTest {
	
	@Mock
	private  TopicDao topicRepository;
	@Mock
	private  GameDao gameRepository;
	@Mock
	private  StoryDao storyRepository;

	
	@InjectMocks
	private  TopicService topServ;
	@InjectMocks
	private  GameService gameServ;
	@InjectMocks
	private  StoryService stoServ;

	
	private TsscTopic correctTopic;
	
	private TsscGame correctGame;
	
	private TsscStory correctStory;


	
	@BeforeEach
	public  void setUp() {
		correctTopic = new TsscTopic();
		correctTopic.setName("RPG");
		correctTopic.setDefaultGroups(2);
		correctTopic.setDefaultSprints(2);
		
		correctGame = new TsscGame();
		correctGame.setName("Assasins");
		correctGame.setNGroups(9);
		correctGame.setNSprints(10);
		
		correctStory = new TsscStory();
		correctStory.setDescription("Es una bichiyal");
		correctStory.setTsscGame(correctGame);
		correctStory.setBusinessValue(BigDecimal.valueOf(50000));
		correctStory.setPriority(BigDecimal.TEN);
		correctStory.setInitialSprint(BigDecimal.ONE);
	}
	
		
//	@Test
//	@DisplayName("Save a game implementing a business logic alternative")
//	public void guardarJuego2() {
//			
//		
//		//Time Controls
//		
//		TsscTimecontrol time1 = new TsscTimecontrol();
//		TsscTimecontrol time2 = new TsscTimecontrol();
//		
//		//Setting elements
//		
//		time1.setName("time1"); time2.setName("time2");
//		ArrayList<TsscTimecontrol> times = new ArrayList<>(); times.add(time1); times.add(time2);
//		ArrayList<TsscStory> stories = new ArrayList<>(); stories.add(correctStory);
//		correctTopic.setTsscStories(stories);
//		correctTopic.setTsscTimecontrols(times);
//		correctGame.setTsscTopic(correctTopic);
//		when(gameRepository.save(correctGame)).thenReturn(correctGame);
//		when(topicRepository.findById(correctTopic.getId())).thenReturn(Optional.of(correctTopic));
//		
//
//		//JAMÁS FUNCIONÓ :(
//		
//
//	}

	

}
