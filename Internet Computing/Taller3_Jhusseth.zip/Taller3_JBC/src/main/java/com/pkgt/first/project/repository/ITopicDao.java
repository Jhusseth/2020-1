package com.pkgt.first.project.repository;

import java.util.List;
import java.util.Optional;

import com.pkgt.first.project.model.TsscTopic;


public interface ITopicDao {
	
	public void save(TsscTopic entity);
	public void update(TsscTopic  entity);
	public void delete(TsscTopic  entity);
	public Optional<TsscTopic>  findById(long codigo);
	public List<TsscTopic> findAll();
	public List<TsscTopic> findByName(String name);
	public List<TsscTopic> findByDescription(String description);

}
