package com.pkgt.first.project.repository;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;
import com.pkgt.first.project.model.TsscGame;


@Repository
@Scope("singleton")
public class GameDao implements IGameDao{
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public void save(TsscGame entity) {
		entityManager.persist(entity);
	}

	@Override
	public void update(TsscGame entity) {
		entityManager.merge(entity);
		
	}

	@Override
	public void delete(TsscGame entity) {
		entityManager.remove(entity);
	}

	@Override
	public Optional<TsscGame> findById(long codigo) {
		TsscGame game = entityManager.find(TsscGame.class, codigo);
		if(game!=null) {
			
			return Optional.of(game);					
		}
		
		return Optional.ofNullable(null);
	}

	@Override
	public List<TsscGame> findAll() {
		String query ="Select a from TsscGame a";
		return entityManager.createQuery(query).getResultList();
	}

	@Override
	public List<TsscGame> findByTsscTopicId(long id) {
		String jpql = "Select a from TsscGame a "
					+ "JOIN TsscTopic t ON a.tsscTopic = t "
					+ "WHERE t.id = " + id;
		return entityManager.createQuery(jpql).getResultList();
	}
	
	@Override
	public List<TsscGame> findByTsscTopicName(String name) {
		String jpql = "Select a from TsscGame a "
				+ "JOIN TsscTopic t ON a.tsscTopic = t "
				+ "WHERE t.name = '" + name + "'";
		return entityManager.createQuery(jpql).getResultList();
	}

	@Override
	public List<TsscGame> findByTsscTopicDescription(String description) {
		String jpql = "Select a from TsscGame a "
				+ "JOIN TsscTopic t ON a.tsscTopic = t "
				+ "WHERE t.description = '" + description + "'";
		return entityManager.createQuery(jpql).getResultList();
	}
	

	@Override
	public List<TsscGame> findByScheduledDateAndScheduledDate(String date, String date2) {
		String jpql = "Select a from TsscGame a WHERE scheduledDate BETWEEN '" + date + "' " + "AND "+ "'" + date2 + "' "
					+ "ORDER BY scheduledDate DESC";
		return entityManager.createQuery(jpql).getResultList();
	}

	@Override
	public List<TsscGame> findByScheduledDateAndScheduledTime(String date, String time, String time2) {
		String jpql = "Select a from TsscGame a WHERE a.scheduledDate = '" + date +"'"
					+ " AND scheduledTime BETWEEN '" + time + "' " + "AND " + "'"+ time2 +"'"
					+ " ORDER BY scheduledTime ASC";
		return entityManager.createQuery(jpql).getResultList();
	}

}
