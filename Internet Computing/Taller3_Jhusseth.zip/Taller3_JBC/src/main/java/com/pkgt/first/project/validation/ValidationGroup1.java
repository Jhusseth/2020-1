package com.pkgt.first.project.validation;

public interface ValidationGroup1 {

}
