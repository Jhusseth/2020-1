package com.pkgt.first.project.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.pkgt.first.project.model.TsscStory;
import com.pkgt.first.project.repository.GameDao;
import com.pkgt.first.project.repository.IGameDao;
import com.pkgt.first.project.repository.IStoryDao;
import com.pkgt.first.project.repository.StoryDao;


@Service
@Scope("singleton")
public class StoryService {

	private IStoryDao storyRepo;
	
	private IGameDao gameRepo;
	
	@Autowired
	public StoryService(StoryDao storyDAO, GameDao gameDAO) {
		
		this.storyRepo = storyDAO;
		this.gameRepo= gameDAO;
	
	}


	@Transactional(readOnly=true, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public TsscStory findById(long id) {
		Optional<TsscStory> tOption = storyRepo.findById(id);
		if(tOption.isPresent()) {
		
			return tOption.get();
		}
		return null;
	}
	
	
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public TsscStory save(TsscStory story) {
			
		if(story==null) {
			return null;
		}
		if(story.getBusinessValue().intValue() >0 && story.getInitialSprint().intValue()>0 && story.getPriority().intValue()>0) {			
			
			//story.setTsscTopic(gameRepository.findById(story.getTsscGame().getId()).get().getTsscTopic());
			
			if(story.getTsscGame()!=null && gameRepo.findById(story.getTsscGame().getId()).isPresent()) {
				
				//Modified del taller 1. ADAPTADO
				
				story.setTsscTopic(gameRepo.findById(story.getTsscGame().getId()).get().getTsscTopic());
				
				storyRepo.save(story);
				return story;
			}
		}
		
		return null;
	
	}
		
	
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public TsscStory modify(TsscStory story) {
			
		if(story==null) {
			return null;
		}
		if(storyRepo.findById(story.getId()).isPresent() && story.getBusinessValue().intValue() >0 && story.getInitialSprint().intValue()>0 && story.getPriority().intValue()>0) {
				
			if(story.getTsscGame()!=null && gameRepo.findById(story.getTsscGame().getId()).isPresent()) {				
					
				storyRepo.update(story);
				return story;
			}
				
		}
		return null;
	}
	
	
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void delete(TsscStory tOption) {
		
		storyRepo.delete(tOption);
	}
	
	
	@Transactional(readOnly=true, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public Iterable<TsscStory> findAll() {
		
		return storyRepo.findAll();
	}

	
}
