package com.pkgt.first.project.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private LoggingAccessDeniedHandler accessDeniedHandler;
	
	@Autowired
	private MyCustomUserDetailsService userDetailsService;

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.authenticationProvider(authenticationProvider());
		auth.jdbcAuthentication().init(auth);
	}

	@Bean
	public DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
		authProvider.setUserDetailsService(userDetailsService);
		authProvider.setPasswordEncoder(encoder());
		return authProvider;
	}

	@Bean
	public PasswordEncoder encoder() {
		return new BCryptPasswordEncoder(11);
	}
	
	@Override
	protected void configure(HttpSecurity httpSecurity) throws Exception {


		httpSecurity
		.authorizeRequests()
		.antMatchers("/h2-console/**").access("hasRole('superAdmin')")
		.antMatchers("/admins").access("hasRole('superAdmin')")
		.antMatchers("/admins/add","/admins/add/**","/admins/edit/","/admins/del/**").access("hasRole('superAdmin')")
		.antMatchers("/games").access("hasRole('admin') or hasRole('superAdmin')")
		.antMatchers("/games/add/**","/games/edit/**","/games/del/**","/games/stories/**").access("hasRole('admin') or hasRole('superAdmin')")
		.antMatchers("/games/topic/**","/games/topic/edit/**","/games/topic/del/**").access("hasRole('superAdmin') or hasRole('admin')")
		.antMatchers("/topics").access("hasRole('superAdmin')")
		.antMatchers("/topics/add","/topics/add/**","/topics/edit/","/topics/del/**").access("hasRole('superAdmin')")
		.antMatchers("/h2-console/**").hasRole("superAdmin")
		.anyRequest().authenticated()
		.and()
		.formLogin()
		.loginPage("/login")
		.permitAll()
		.defaultSuccessUrl("/")
		.failureUrl("/login?error=true")
		.usernameParameter("userName")
		.passwordParameter("password")
		.and()
		.logout()
		.logoutRequestMatcher(new AntPathRequestMatcher("/logout")).logoutSuccessUrl("/login?logout")
		.permitAll().and().exceptionHandling().accessDeniedHandler(accessDeniedHandler)
		.and().csrf().ignoringAntMatchers("/h2-console/**")
		.and().headers().frameOptions().sameOrigin();;
	}
}