package com.pkgt.first.project;


import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.pkgt.first.project.model.AdminType;
import com.pkgt.first.project.model.TsscAdmin;
import com.pkgt.first.project.service.AdminService;

@SpringBootApplication
@EnableJpaRepositories("com.pkgt.first.project.repository")
@EntityScan("com.pkgt.first.project.model")
@ComponentScan({"com.pkgt.first.project"})
public class WorkShopApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext c = SpringApplication.run(WorkShopApplication.class, args);
		}
	
	@Bean
	public CommandLineRunner demo(AdminService adminRepository) {
		return (args) -> {
			
			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
			
			TsscAdmin admin = new TsscAdmin();	
			admin.setUser("chapu");
			admin.setType(AdminType.admin);
			admin.setSuperAdmin("admin");
			admin.setPassword(passwordEncoder.encode("2000"));
			
			TsscAdmin superAdmin = new TsscAdmin();	
			superAdmin.setUser("jhusseth");
			superAdmin.setType(AdminType.superAdmin);
			admin.setSuperAdmin("superAdmin");
			superAdmin.setPassword(passwordEncoder.encode("1998"));
			
			adminRepository.save(admin);
			adminRepository.save(superAdmin);
			
		};
	}


	
}

