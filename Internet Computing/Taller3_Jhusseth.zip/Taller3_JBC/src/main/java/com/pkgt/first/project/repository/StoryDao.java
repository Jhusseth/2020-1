package com.pkgt.first.project.repository;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.pkgt.first.project.model.TsscStory;


@Repository
@Scope("singleton")
public class StoryDao implements IStoryDao{
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public void save(TsscStory entity) {
		entityManager.persist(entity);
	}

	@Override
	public void update(TsscStory entity) {
		entityManager.merge(entity);
	}

	@Override
	public void delete(TsscStory entity) {
		entityManager.remove(entity);
	}

	@Override
	public Optional<TsscStory> findById(long codigo) {
		TsscStory story = entityManager.find(TsscStory.class, codigo);
		if(story!=null) {
			return Optional.of(story);					
		}
		return Optional.ofNullable(null);
	}
	
	public TsscStory findByDescription(String desc) {	
		String consulta = "SELECT element FROM TsscStory element "
						+ "WHERE element.description = '" +desc +"'";
		return (TsscStory) entityManager.createQuery(consulta).getSingleResult();
		
	}

	@Override
	public List<TsscStory> findAll() {
		String query = "SELECT a FROM TsscStory a";
		return entityManager.createQuery(query).getResultList();
	}

}
