package com.pkgt.first.project.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.pkgt.first.project.model.TsscAdmin;
import com.pkgt.first.project.repository.IAdminDao;

@Service
@Scope("singleton")
public class AdminService {

@Autowired
IAdminDao adminDAO;
	
@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public void save(TsscAdmin admin) {
		
	adminDAO.save(admin);
	
}


//

}
