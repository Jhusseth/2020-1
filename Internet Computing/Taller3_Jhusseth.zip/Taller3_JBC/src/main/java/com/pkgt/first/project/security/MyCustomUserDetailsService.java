package com.pkgt.first.project.security;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.pkgt.first.project.model.TsscAdmin;
import com.pkgt.first.project.repository.AdminDao;

@Service
public class MyCustomUserDetailsService implements UserDetailsService {
	
	@Autowired
	AdminDao adminRepo;
	
	
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		TsscAdmin admin = adminRepo.findByUser(username);
		
		if (admin != null) {
			User.UserBuilder builder = User.withUsername(username).password(admin.getPassword()).roles(admin.getType().toString());
			return builder.build();
		} 
		else {
			throw new UsernameNotFoundException("Administrator not found.");		
		}
	}
}