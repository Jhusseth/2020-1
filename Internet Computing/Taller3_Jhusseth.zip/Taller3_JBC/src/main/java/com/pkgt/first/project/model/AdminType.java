package com.pkgt.first.project.model;

public enum AdminType {
	admin,superAdmin
}
