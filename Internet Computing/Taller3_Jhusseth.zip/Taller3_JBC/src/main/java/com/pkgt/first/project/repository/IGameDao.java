package com.pkgt.first.project.repository;

import java.util.List;
import java.util.Optional;

import com.pkgt.first.project.model.TsscGame;

public interface IGameDao {
	
	public void save(TsscGame entity);
	public void update(TsscGame  entity);
	public void delete(TsscGame  entity);
	public Optional<TsscGame>  findById(long codigo);
	public List<TsscGame> findAll();
	
	public List<TsscGame> findByTsscTopicId(long id);
	public List<TsscGame> findByTsscTopicName(String name);
	public List<TsscGame> findByTsscTopicDescription(String description);
	
	public List<TsscGame> findByScheduledDateAndScheduledDate(String date,String date2);
	public List<TsscGame> findByScheduledDateAndScheduledTime(String date,String time,String time2);

}
