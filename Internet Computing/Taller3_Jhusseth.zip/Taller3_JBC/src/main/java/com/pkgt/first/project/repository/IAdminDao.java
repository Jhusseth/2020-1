package com.pkgt.first.project.repository;

import java.util.List;

import com.pkgt.first.project.model.TsscAdmin;


public interface IAdminDao {
	
	public void save(TsscAdmin entity);
	public void update(TsscAdmin  entity);
	public void delete(TsscAdmin  entity);
	public TsscAdmin  findById(long codigo);
	public List<TsscAdmin> findAll();

}
