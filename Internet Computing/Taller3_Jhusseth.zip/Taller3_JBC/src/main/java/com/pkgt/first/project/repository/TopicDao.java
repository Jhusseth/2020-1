package com.pkgt.first.project.repository;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.pkgt.first.project.model.TsscTopic;


@Repository
@Scope("singleton")
public class TopicDao implements ITopicDao{
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public void save(TsscTopic entity) {
		entityManager.persist(entity);
	}

	@Override
	public void update(TsscTopic entity) {
		entityManager.merge(entity);
	}

	@Override
	public void delete(TsscTopic entity) {
		entityManager.remove(entity);
	}

	@Override
	public Optional<TsscTopic> findById(long codigo) {
		TsscTopic topic = entityManager.find(TsscTopic.class, codigo);
		if(topic!=null) {
			
			return Optional.of(topic);					
		}
		
		return Optional.ofNullable(null);
	}

	@Override
	public List<TsscTopic> findAll() {
		String query = "Select a from TsscTopic a";
		return entityManager.createQuery(query).getResultList();
	}

	@Override
	public List<TsscTopic> findByName(String name) {
		String jpql = "Select a from TsscTopic a WHERE a.name = '" + name + "'";
		return entityManager.createQuery(jpql).getResultList();
	}

	@Override
	public List<TsscTopic> findByDescription(String description) {
		String jpql = "Select a from TsscTopic a WHERE a.description = '" + description + "'";
		return entityManager.createQuery(jpql).getResultList();
	}

}
