package com.pkgt.first.project.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.pkgt.first.project.model.TsscGame;
import com.pkgt.first.project.model.TsscStory;
import com.pkgt.first.project.model.TsscTopic;
import com.pkgt.first.project.service.AdminService;
import com.pkgt.first.project.service.GameService;
import com.pkgt.first.project.service.StoryService;
import com.pkgt.first.project.service.TopicService;
import com.pkgt.first.project.validation.ValidationGroup1;
import com.pkgt.first.project.validation.ValidationGroup2;

@Controller
public class GamesController  {

	@Autowired
	StoryService storyService;
	
	@Autowired
	GameService gameService;
	
	@Autowired
	TopicService topicService;


	
	@GetMapping("/games")
	public String indexGame(Model model) {
		model.addAttribute("games", gameService.findAll());
		return "games/index";
	}
	
	
	@GetMapping("/games/add")
	public String addGame(Model model) {
		model.addAttribute("game", new TsscGame());
		List<TsscTopic> topics = (List<TsscTopic>) topicService.findAll();
		model.addAttribute("topics", topics);
		return "games/add-game";
	}
	
	@PostMapping("/games/add")
	public String saveGame(@Validated(ValidationGroup1.class) TsscGame game,BindingResult result, @RequestParam(value = "action", required = true) String action,Model model) {
	 if (!action.equals("Cancel")) {
		 if(result.hasErrors()) {
			 	model.addAttribute("game", game);
				model.addAttribute("topics", topicService.findAll());
				return "games/add";
		 } 
		 gameService.save(game);	 
	 }
		 return "redirect:/games";	
	}
	
	
	@GetMapping("/games/edit/{id}")
	public String showUpdateFormGame(@PathVariable("id") long id, Model model) {
		TsscGame game = gameService.findById(id);
		if (game == null) {
			throw new IllegalArgumentException("Invalid user Id:" + id);
		}
		model.addAttribute("game", game);
		model.addAttribute("topics", topicService.findAll());
		return "games/update-game";
	}
	
	@PostMapping("/games/edit/{id}")
	public String updateGame(@Validated(ValidationGroup1.class) TsscGame game,  BindingResult result,@PathVariable("id") long id,
			@RequestParam(value = "action", required = true) String action, Model model) {
		if (action != null && !action.equals("Cancel")) {
			
			if(result.hasErrors()) {
				model.addAttribute("game", game);
				model.addAttribute("topics", topicService.findAll());
				return "games/edit/{id}";
			}
			gameService.save(game);
		}
		return "redirect:/games";
	}
	
	@GetMapping("/games/del/{id}")
	public String deleteGame(@PathVariable("id") long id) {
		TsscGame game = gameService.findById(id);
		gameService.delete(game);
		return "redirect:/games";
	}
	
	
	@GetMapping("/games/stories/{id}")
	public String storiesGame(@PathVariable("id") long id,Model model) {
		TsscGame gam = gameService.findById(id); 
		model.addAttribute("stories", gam.getTsscStories());
		model.addAttribute("gameName", gam.getName());
		return "games/stories";
	}
	
	@GetMapping("/games/topic/{id}")
	public String showTopic(Model model, @PathVariable("id") long id) {
		
		TsscGame gam = gameService.findById(id);
		if(gam.getTsscTopic()!=null) {
			
			List<TsscTopic> z = new ArrayList<>();
			z.add(gam.getTsscTopic());
			model.addAttribute("topics", z);
		}
		
		model.addAttribute("gameName", gam.getName());
		return "stories/topicGame";
	}
	
	
	
}
