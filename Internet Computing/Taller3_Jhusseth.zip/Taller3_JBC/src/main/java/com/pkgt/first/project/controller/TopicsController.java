package com.pkgt.first.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.pkgt.first.project.model.TsscTopic;
import com.pkgt.first.project.service.TopicService;
import com.pkgt.first.project.validation.ValidationGroup1;

@Controller
public class TopicsController {
	
	@Autowired
	TopicService service;
	
	@GetMapping("/topics")
	public String indexTopic(Model model) {
		model.addAttribute("topics", service.findAll());
		return "topics/index";
	}
	
	@GetMapping("/topics/add")
	public String addTopic(Model model) {
		model.addAttribute("topic", new TsscTopic());
		return "topics/add-topic";
	}
	
	@PostMapping("/topics/add")
	public String saveTopic(@Validated(ValidationGroup1.class) TsscTopic topic, BindingResult result, @RequestParam(value = "action", required = true) String action,Model model) {
	 if (!action.equals("Cancel")) {
		 if(result.hasErrors()) {
			 model.addAttribute("topic", topic);
			 return "topics/add-topic";
		 } 
		 service.save(topic);	 
	 }
		 return "redirect:/topics";	
	}
	
	@GetMapping("/topics/edit/{id}")
	public String showUpdateFormTopic(@PathVariable("id") long id, Model model) {
		TsscTopic topic = service.findById(id);
		if (topic == null) {
			throw new IllegalArgumentException("Invalid user Id:" + id);
		}
		model.addAttribute("topic", topic);
		return "topics/update-topic";
	}
	
	@PostMapping("/topics/edit/{id}")
	public String updateTopic(@Validated(ValidationGroup1.class) TsscTopic topic,  BindingResult result,@PathVariable("id") long id,
			@RequestParam(value = "action", required = true) String action, Model model) {
		if (action != null && !action.equals("Cancel")) {		
			if(result.hasErrors()) {
				return "redirect:/topics/edit/{id}";
			}
			service.save(topic);
		}
		return "redirect:/topics";
	}
	
	@GetMapping("/topics/del/{id}")
	public String deleteTopic(@PathVariable("id") long id) {
		TsscTopic topic = service.findById(id);
		service.delete(topic);
		return "redirect:/topics";
	}
	
	@GetMapping("/topics/stories/{id}")
	public String showStories(Model model, @PathVariable("id") long id) {
		
		TsscTopic game = service.findById(id); 
		model.addAttribute("stories", game.getTsscStories());
		model.addAttribute("gameName", game.getName());
		
		return "topics/storyTopic";
	}
	
	@GetMapping("/topics/games/{id}")
	public String showGames(Model model, @PathVariable("id") long id) {
		
		TsscTopic game = service.findById(id); 
		model.addAttribute("games", game.getTsscGames());
		model.addAttribute("gameName", game.getName());
		return "topics/gameTopic";
		
		
	}
	
	

}
