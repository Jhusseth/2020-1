package com.pkgt.first.project.service;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.pkgt.first.project.model.TsscGame;
import com.pkgt.first.project.model.TsscStory;
import com.pkgt.first.project.model.TsscTimecontrol;
import com.pkgt.first.project.model.TsscTopic;
import com.pkgt.first.project.repository.GameDao;
import com.pkgt.first.project.repository.IGameDao;
import com.pkgt.first.project.repository.IStoryDao;
import com.pkgt.first.project.repository.ITimeControlDao;
import com.pkgt.first.project.repository.ITopicDao;
import com.pkgt.first.project.repository.StoryDao;
import com.pkgt.first.project.repository.TimeControlDao;
import com.pkgt.first.project.repository.TopicDao;


@Service
public class GameService {

	private IGameDao gameRepo;
		
	private ITopicDao topicRepo;
		
	private IStoryDao storyRepo;
	
	private ITimeControlDao timeControlRepo;


	@Autowired
	public GameService(GameDao gameDAO, TopicDao topicDAO, StoryDao storyDAO, TimeControlDao timeControlDAO) {
			
		this.gameRepo = gameDAO;
		this.topicRepo = topicDAO;
		this.storyRepo = storyDAO;
		this.timeControlRepo = timeControlDAO;
			
		
	}

	@Transactional(readOnly=true, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public TsscGame findById(long id) {
		
		Optional<TsscGame> gOption = gameRepo.findById(id);
		if(gOption.isPresent()) {
			return gOption.get();
		}
		
		return null;
		
	}
	
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)	
	public TsscGame save(TsscGame game) {
		
		if(game==null)
		return null;
		if(game.getNGroups()>0 && game.getNSprints()>0 ) {
		
			if(game.getTsscTopic()==null) {	
			
				gameRepo.save(game);
			return game;
			}
		
			else{
				Optional<TsscTopic> optionT =  topicRepo.findById(game.getTsscTopic().getId());
				if(optionT.isPresent()) {
						
					gameRepo.save(game);
					
					ArrayList<TsscStory> stories = new ArrayList<TsscStory>();
					ArrayList<TsscTimecontrol> timecontrols = new ArrayList<TsscTimecontrol>();
					
					if(optionT.get().getTsscStories() != null) {
					
					for (TsscStory tOption : optionT.get().getTsscStories()) {
						
						//Modified del taller 1. ADAPTADO
						
						TsscStory storyOption= new TsscStory();
						
						storyOption.setAltDescripton(tOption.getAltDescripton());
						storyOption.setBusinessValue(tOption.getBusinessValue());
						storyOption.setDescription(tOption.getDescription());
						storyOption.setInitialSprint(tOption.getInitialSprint());
						storyOption.setPriority(tOption.getPriority());
						storyOption.setShortDescription(tOption.getShortDescription());							
						storyOption.setNumber(tOption.getNumber());
						storyOption.setTsscTopic(tOption.getTsscTopic());
						storyOption.setTsscGame(game);
						
						stories.add(storyOption);
						storyRepo.save(storyOption);
				
					}
				
				}
			
				if(optionT.get().getTsscTimecontrols() != null) {
					
				for (TsscTimecontrol tOption : optionT.get().getTsscTimecontrols()) {			
						
					TsscTimecontrol storyOption = new TsscTimecontrol();
					
					storyOption.setName(tOption.getName());
					storyOption.setTimeInterval(tOption.getTimeInterval());
					storyOption.setName(tOption.getName());
					storyOption.setAutostart(tOption.getAutostart());
					storyOption.setIntervalRunning(tOption.getIntervalRunning());
					storyOption.setTsscGame(game);
					
					timecontrols.add(storyOption);
					timeControlRepo.save(storyOption);
						
					}
				}
						
			
				
				game.setTsscStories(stories);
				game.setTsscTimecontrol(timecontrols);
				
					return game;
				
				}
		
			}
		
		}
	
		return null;
	}


	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public TsscGame modify(TsscGame game) {
		if(game==null)
			return null;
		if(gameRepo.findById(game.getId()).isPresent() && game.getNGroups()>0 && game.getNSprints()>0) {
			
			if(game.getTsscTopic()==null) {		
				
				gameRepo.update(game);
				return game;
			}
			else if(topicRepo.findById(game.getTsscTopic().getId()).isPresent()) {
				
				gameRepo.update(game);
				return game;
			}
		}
		return null;
	}


	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void delete(TsscGame tOption) {
		gameRepo.delete(tOption);
	}
	
	
	
	@Transactional(readOnly=true, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public Iterable<TsscGame> findAll() {
		
		return gameRepo.findAll();
	
	}

}

