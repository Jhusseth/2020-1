package com.pkgt.first.project.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.pkgt.first.project.model.TsscAdmin;
import com.pkgt.first.project.service.AdminService;
import com.pkgt.first.project.validation.ValidationGroup1;
import com.pkgt.first.project.validation.ValidationGroup3;


@Controller
public class AdminsController {

//	AdminService adminService;
//
//	@Autowired
//	public AdminsController(AdminService adminService) {
//		this.adminService = adminService;
//	}
//	
//	@GetMapping("/")
//	public String indexGeneral(Model model, TsscAdmin admin) {
//		model.addAttribute("admin",admin);
//		return "/index";
//	}
//	
//	@GetMapping("/login")
//	public String loginPage(Model model ) {
//		
//		model.addAttribute("admins", adminService.findAllAdmins());
//		model.addAttribute("admin", new TsscAdmin());
//		
//		return "admins/login-page";
//	}
//	@PostMapping("/login")
//	public String loginPage(Model model,@Validated(ValidationGroup3.class) TsscAdmin admin,BindingResult result) {
//		
//		if(result.hasErrors()) {
//			
//			return "admins/login-page";
//		}
//		model.addAttribute("admins", adminService.findAllAdmins());
//	
//		return "redirect:/";
//	}
//	
//	@GetMapping("/admins")
//	public String admisIndex(Model model) {
//		model.addAttribute("admins", adminService.findAllAdmins());
//		return "/admins/index";
//	}
//	
//	
//	@GetMapping("/admins/add")
//	public String addAdmins(Model model) {
//		model.addAttribute("admin", new TsscAdmin());
//		model.addAttribute("types", adminService.getTypes());
//		return "admins/add-admin";
//	}
//	
//	@PostMapping("/admins/add")
//	public String saveAdmin(@Validated(ValidationGroup1.class) TsscAdmin admin, BindingResult result, @RequestParam(value = "action", required = true) String action) {
//	 if (!action.equals("Cancel")) {
//		 if(result.hasErrors()) {
//			 return "admins/add-admins";
//		 } 
//		 BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
//		 String pass = passwordEncoder.encode(admin.getPassword());
//		 admin.setPassword(pass);
//		 adminService.saveAdmin(admin);	 
//	 }
//		 return "redirect:/admins";	
//	}
//	
//	
//	@GetMapping("/admins/edit/{id}")
//	public String showUpdateFormAdmin(@PathVariable("id") long id, Model model) {
//		Optional<TsscAdmin> admin = adminService.findByAdminId(id);
//		if (admin == null) {
//			throw new IllegalArgumentException("Invalid user Id:" + id);
//		}
//		model.addAttribute("admin", admin.get());
//		model.addAttribute("types", adminService.getTypes());
//		return "admins/update-admin";
//	}
//	
//	@PostMapping("/admins/edit/{id}")
//	public String updateAdmin(@Validated(ValidationGroup1.class) TsscAdmin admin,  BindingResult result,@PathVariable("id") long id,
//			@RequestParam(value = "action", required = true) String action, Model model) {
//		if (action != null && !action.equals("Cancel")) {
//			
//			if(result.hasErrors()) {
//				model.addAttribute("types", adminService.getTypes());
//				return "admin/edit/{id}";
//			}
//			model.addAttribute("types", adminService.getTypes());
//			
//			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
//			String pass = passwordEncoder.encode(admin.getPassword());
//			admin.setPassword(pass);
//			
//			adminService.saveAdmin(admin);
//		}
//		return "redirect:/admins";
//	}
//	@GetMapping("/admins/del/{id}")
//	public String deleteAdmin(@PathVariable("id") long id) {
//		TsscAdmin admin = adminService.findByAdminId(id).orElseThrow(() -> new IllegalArgumentException("Invalid topic Id:" + id));
//		adminService.deleteAdmin(admin);
//		return "redirect:/admins";
//	}
//	
//	@GetMapping("/access-denied")
//	public String access(Model model) {
//		
//		return "access-denied";
//	}
//	

}
