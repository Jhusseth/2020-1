package com.pkgt.first.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.pkgt.first.project.model.TsscTimecontrol;
import com.pkgt.first.project.repository.ITimeControlDao;
import com.pkgt.first.project.repository.TimeControlDao;



@Service
@Scope("singleton")
public class TimeControlService {

	ITimeControlDao timeControlRepo;
	
	@Autowired
	public TimeControlService(TimeControlDao timeControlDAO) {
		
		super();
		this.timeControlRepo = timeControlDAO;
		
	}
		
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)	
	public void save(TsscTimecontrol tOption) {
	
		timeControlRepo.save(tOption);
		
	}
		
}
