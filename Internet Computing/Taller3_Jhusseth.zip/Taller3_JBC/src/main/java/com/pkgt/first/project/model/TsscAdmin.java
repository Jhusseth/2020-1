package com.pkgt.first.project.model;

import java.io.Serializable;
import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.pkgt.first.project.validation.ValidationGroup1;
import com.pkgt.first.project.validation.ValidationGroup3;

import java.util.List;

/**
 * The persistent class for the TSSC_ADMIN database table.
 * 
 */
@Entity
@Table(name = "TSSC_ADMIN")
@NamedQuery(name = "TsscAdmin.findAll", query = "SELECT t FROM TsscAdmin t")
public class TsscAdmin implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "TSSC_ADMIN_ID_GENERATOR", allocationSize = 1, sequenceName = "TSSC_ADMIN_SEQ")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TSSC_ADMIN_ID_GENERATOR")
	private long id;
	
	@Size(min=4,groups=ValidationGroup1.class,message = "the character size must be greater than 4")
	@NotEmpty(message="the password can't be empty",groups=ValidationGroup3.class)
	private String password;

	@NotEmpty(message="the rol can't be empty",groups=ValidationGroup3.class)
	@Column(name = "SUPER_ADMIN")
	private String superAdmin;

	@NotEmpty(message="the user can't be empty",groups=ValidationGroup1.class)
	@Column(name = "AD_USER")
	private String user;
	
	@NotNull(message="the type cannot be empty",groups=ValidationGroup1.class)
	public AdminType type;

	// bi-directional many-to-one association to TsscState
	@ManyToOne
	@JoinColumn(name = "TSSC_STATE_ID")
	private TsscState tsscState;

	// bi-directional many-to-one association to TsscGameAdmin
	@OneToMany(mappedBy = "tsscAdmin")
	private List<TsscGameAdmin> tsscGameAdmins;

	public TsscAdmin() {
	}
	
	public AdminType getType() {
		return type;
	}
	
	public void setType(AdminType type) {
		this.type=type;
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}
	

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSuperAdmin() {
		return this.superAdmin;
	}

	public void setSuperAdmin(String superAdmin) {
		this.superAdmin = superAdmin;
	}

	public String getUser() {
		return this.user;
	}
	

	public void setUser(String user) {
		this.user = user;
	}

	public TsscState getTsscState() {
		return this.tsscState;
	}

	public void setTsscState(TsscState tsscState) {
		this.tsscState = tsscState;
	}

	public List<TsscGameAdmin> getTsscGameAdmins() {
		return this.tsscGameAdmins;
	}

	public void setTsscGameAdmins(List<TsscGameAdmin> tsscGameAdmins) {
		this.tsscGameAdmins = tsscGameAdmins;
	}

	public TsscGameAdmin addTsscGameAdmin(TsscGameAdmin tsscGameAdmin) {
		getTsscGameAdmins().add(tsscGameAdmin);
		tsscGameAdmin.setTsscAdmin(this);

		return tsscGameAdmin;
	}

	public TsscGameAdmin removeTsscGameAdmin(TsscGameAdmin tsscGameAdmin) {
		getTsscGameAdmins().remove(tsscGameAdmin);
		tsscGameAdmin.setTsscAdmin(null);

		return tsscGameAdmin;
	}

}