package com.pkgt.first.project.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.pkgt.first.project.model.TsscTopic;
import com.pkgt.first.project.repository.ITopicDao;
import com.pkgt.first.project.repository.TopicDao;



@Service
@Scope("singleton")
public class TopicService {
	

	private ITopicDao topicRepo;
		
		
	@Autowired
	public TopicService(TopicDao tOption) {
			
		topicRepo = tOption;
	}
		
	
	@Transactional(readOnly=true, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)		
	public TsscTopic findById(long id) {
			
		Optional<TsscTopic> tOption = topicRepo.findById(id);
		if(tOption.isPresent()) {
			
			return tOption.get();
		}
		return null;
	}
	
	
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public TsscTopic save(TsscTopic topic) {
		
		if(topic==null)
			return null;
		
		if(topic.getDefaultGroups()>0 && topic.getDefaultSprints()>0 ) {
			topicRepo.save(topic);
			return topic;
			
		}
		
		return null;
	
	}
	
	
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public TsscTopic modify(TsscTopic topic) {
		
		if(topic==null)
			return null;
		
		if(topicRepo.findById(topic.getId()).isPresent() && topic.getDefaultGroups()>0 && topic.getDefaultSprints()>0) {
			topicRepo.save(topic);
			return topic;
			}
			
		return null;
		
	}
	
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public void delete(TsscTopic tOption) {
		topicRepo.delete(tOption);
	}
		
	
	@Transactional(readOnly=true, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public Iterable<TsscTopic> findAll(){
			
		return topicRepo.findAll();
	
	}
	
}
