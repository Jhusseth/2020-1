package com.pkgt.first.project.repository;

import java.util.List;
import java.util.Optional;

import com.pkgt.first.project.model.TsscStory;

public interface IStoryDao {
	
	public void save(TsscStory entity);
	public void update(TsscStory entity);
	public void delete(TsscStory  entity);
	public Optional<TsscStory>  findById(long codigo);
	public List<TsscStory> findAll();

}
