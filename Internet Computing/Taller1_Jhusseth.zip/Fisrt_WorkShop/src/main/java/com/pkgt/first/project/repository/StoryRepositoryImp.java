package com.pkgt.first.project.repository;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.pkgt.first.project.model.TsscStory;

@Repository
public class StoryRepositoryImp implements StoryRepository {
	
	private  Map<Long,TsscStory> story;
	
	@Autowired
	public GameRepository game;
	
	

	public StoryRepositoryImp() {
		this.story = new HashMap<>();
	}

	@Override
	public void storyEdit(Long gameId,Long id, String altDescShown, String altDescription, BigDecimal businessValue,
			String description, BigDecimal initialSpring, BigDecimal number, BigDecimal priority,
			String shortDescription) {
		
		TsscStory st = story.get(id) ;
		
		if(st!=null ) {
			if(st.getTsscGame()==null) {
				st.setId(id);
				st.setAltDescShown(altDescShown);
				st.setAltDescripton(altDescription);
				st.setBusinessValue(businessValue);
				st.setDescription(description);
				st.setInitialSprint(initialSpring);
				st.setNumber(number);
				st.setPriority(priority);
				st.setShortDescription(shortDescription);	
				
				story.remove(id);
				story.put(st.getId(), st);
			}
		}
	}

	@Override
	public void storySave(Long gameId, TsscStory story) {
		if(this.game.consulGame(gameId)!=null) {
			game.consulGame(gameId).addTsscStory(story);
			this.story.put(story.getId(),story);
		}
	}

	@Override
	public Map<Long, TsscStory> getStorys() {
		return story;
	}

	@Override
	public void stSave(TsscStory story) {
		this.story.put(story.getId(), story);
	}
	
	

}
