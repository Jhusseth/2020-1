package com.pkgt.first.project.repository;

import java.math.BigDecimal;
import java.util.Map;
import com.pkgt.first.project.model.TsscStory;

public interface StoryRepository {
	
	public void storyEdit(Long GameId,Long id,String altDescShow,String altDescription,BigDecimal businessValue,String descripcion,
			BigDecimal initialSpring,BigDecimal number,BigDecimal priority,String ShortDescription);
	
	public void storySave(Long gameId,TsscStory story);
	
	public void stSave(TsscStory story);
	
	public Map<Long,TsscStory> getStorys();
	

}
