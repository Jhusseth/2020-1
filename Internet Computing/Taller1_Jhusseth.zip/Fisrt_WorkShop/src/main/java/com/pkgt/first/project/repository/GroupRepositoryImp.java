package com.pkgt.first.project.repository;

import com.pkgt.first.project.model.TsscGroup;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository
public class GroupRepositoryImp implements GroupRepository {
	
	public Map<Long,TsscGroup> group;
	
	

	public GroupRepositoryImp() {
		this.group = new HashMap<>();
	}

	@Override
	public void addGroup(TsscGroup group) {
		this.group.put(group.getId(), group);
	}
	
	@Override
	public Map<Long,TsscGroup> getGroups(){
		return group;
	}

	@Override
	public void delete(Long id) {
		group.remove(id);
	}

}
