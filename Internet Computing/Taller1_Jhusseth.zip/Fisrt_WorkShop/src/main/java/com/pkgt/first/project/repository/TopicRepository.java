package com.pkgt.first.project.repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Map;

import com.pkgt.first.project.model.TsscGame;
import com.pkgt.first.project.model.TsscTopic;

public interface TopicRepository {
	
	public void topicSave(TsscTopic tp);
	public void topicEdit(Long id,String description, String name, Long Sprints, Long Groups, String group);
	public TsscTopic consultTopic(Long id);
	public Map<Long,TsscTopic> getTopics();
	public boolean GameTopicSave(TsscGame gm,Long topicId, String adminPassword, String guestPassword, Integer nGroups,
			Integer nSprints, String name, Long pauseSeconds, LocalDate scheduledDate, LocalTime scheduledTime,
			LocalTime startTime, BigDecimal typeGameId, String userPassword);

}
