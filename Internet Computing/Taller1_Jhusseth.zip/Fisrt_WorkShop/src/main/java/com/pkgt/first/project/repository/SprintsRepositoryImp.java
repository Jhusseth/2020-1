package com.pkgt.first.project.repository;

import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Repository;
import com.pkgt.first.project.model.TsscSprint;

@Repository
public class SprintsRepositoryImp implements SprintsRepository {

	public Map<Long,TsscSprint> sprints;
	
	
	
	public SprintsRepositoryImp() {
		this.sprints = new HashMap<>();
	}

	@Override
	public void addSprints(TsscSprint sp) {
		
		sprints.put(sp.getId(), sp);
		
	}
	
	@Override
	public Map<Long,TsscSprint> getSprints(){
		return sprints;
	}

	@Override
	public void delete(Long id) {
		sprints.remove(id);
	}

}
