package com.pkgt.first.project.repository;

import java.math.BigDecimal;
import java.time.LocalTime;
import java.util.Map;

import com.pkgt.first.project.model.TsscTimecontrol;


public interface CronometerRepository {
	
	public void editTimeControl(Long id,String autoStart,BigDecimal intervalRunning,LocalTime lastPlayTime,String name,
			BigDecimal order,String state,BigDecimal timeInterval,String type);
	public void addtimeControlGame(TsscTimecontrol time,Long id);
	public void addtimeControlTopic(TsscTimecontrol time,Long id);
	public void deleteCronometer(Long id,Long gameId);
	public Map<Long, TsscTimecontrol> getTimes();
	

}
