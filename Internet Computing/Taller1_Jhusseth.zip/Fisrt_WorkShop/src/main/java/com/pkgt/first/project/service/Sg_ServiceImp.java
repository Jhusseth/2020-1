package com.pkgt.first.project.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pkgt.first.project.model.TsscGame;
import com.pkgt.first.project.model.TsscGroup;
import com.pkgt.first.project.model.TsscSprint;
import com.pkgt.first.project.model.TsscStory;
import com.pkgt.first.project.model.TsscTimecontrol;
import com.pkgt.first.project.model.TsscTopic;
import com.pkgt.first.project.repository.CronometerRepository;
import com.pkgt.first.project.repository.GameRepository;
import com.pkgt.first.project.repository.StoryRepository;
import com.pkgt.first.project.repository.TopicRepository;

@Service
public class Sg_ServiceImp implements Sg_Service{
	
	@Autowired
	private GameRepository game;
	
	@Autowired
	private TopicRepository topic;
	
	
	@Autowired
	private StoryRepository story;
	
	@Autowired
	private CronometerRepository time;
	
	

	@Override
	public void TopicEdit(Long id, String description, String name, Long Sprints, Long Groups, String group) {
		topic.topicEdit(id, description, name, Sprints, Groups, group);
	}

	@Override
	public boolean TopicSave(TsscTopic tp,String description, String name, Long sprints, Long groups, String groupPrefix) {
		
		tp.setDescription(description);
		tp.setName(name);
		tp.setDefaultSprints(sprints);
		tp.setDefaultGroups(groups);
		tp.setGroupPrefix(groupPrefix);
		
		if(tp.getDefaultGroups()>0 && tp.getDefaultSprints()>0) {
			topic.topicSave(tp);
			return true;
		}
		
		return false;
		
	}

	@Override
	public void GameEdit(Long id, String adminPassword, String guestPassword, Integer nGroups, Integer nSprints,
			String name, Long pauseSeconds, LocalDate scheduledDate, LocalTime scheduledTime, LocalTime startTime,
			BigDecimal typeGameId, String userPassword) {
		
		game.gameEdit(id, adminPassword, guestPassword, nGroups, nSprints, name, pauseSeconds, scheduledDate, scheduledTime, startTime, typeGameId, userPassword);
		
	}

	@Override
	public boolean GameSave(TsscGame gm,String adminPassword, String guestPassword, Integer nGroups, Integer nSprints, String name,
			Long pauseSeconds, LocalDate scheduledDate, LocalTime scheduledTime, LocalTime startTime,
			BigDecimal typeGameId, String userPassword) {
		
		gm.setAdminPassword(adminPassword);
		gm.setGuestPassword(guestPassword);
		gm.setName(name);
		gm.setNGroups(nGroups);
		gm.setNSprints(nSprints);
		gm.setPauseSeconds(pauseSeconds);
		gm.setScheduledDate(scheduledDate);
		gm.setScheduledTime(scheduledTime);
		gm.setStartTime(startTime);
		gm.setTypegameId(typeGameId);
		gm.setUserPassword(userPassword);
		
		
		if(game.consulGame(gm.getId()).getTsscSprints().size()>0 && game.consulGame(gm.getId()).getTsscGroups().size()>0) {
			game.gameSave(gm);
			return true;
		}
			
		
		
		return false;
	}

	@Override
	public void StoryEdit(Long gameId,Long id, String altDescShow, String altDescription, BigDecimal businessValue,
			String descripcion, BigDecimal initialSpring, BigDecimal number, BigDecimal priority,
			String ShortDescription) {
		
		story.storyEdit(gameId,id, altDescShow, altDescription, businessValue, descripcion, initialSpring, number, priority, ShortDescription);
		
	}

	@Override
	public boolean StorySaveGame(TsscStory st,Long gameId,String altDescShown, String altDescription, BigDecimal businessValue, String description,
			BigDecimal initialSpring, BigDecimal number, BigDecimal priority, String shortDescription) {
		
		st.setAltDescShown(altDescShown);
		st.setAltDescripton(altDescription);
		st.setBusinessValue(businessValue);
		st.setDescription(description);
		st.setInitialSprint(initialSpring);
		st.setNumber(number);
		st.setPriority(priority);
		st.setShortDescription(shortDescription);
		
		if(st.getInitialSprint().toBigIntegerExact().intValue()>0 && st.getPriority().toBigIntegerExact().intValue()>0) {
			if(game.consulGame(gameId)!=null) {
				story.storySave(gameId, st);
				return true;
			}
		}
		return false;
	}

	@Override
	public void GameTopicSave(TsscGame gm,Long topicId, String adminPassword, String guestPassword, Integer nGroups,
			Integer nSprints, String name, Long pauseSeconds, LocalDate scheduledDate, LocalTime scheduledTime,
			LocalTime startTime, BigDecimal typeGameId, String userPassword) {
		
		gm.setAdminPassword(adminPassword);
		gm.setGuestPassword(guestPassword);
		gm.setName(name);
		gm.setNGroups(nGroups);
		gm.setNSprints(nSprints);
		gm.setPauseSeconds(pauseSeconds);
		gm.setScheduledDate(scheduledDate);
		gm.setScheduledTime(scheduledTime);
		gm.setStartTime(startTime);
		gm.setTypegameId(typeGameId);
		gm.setUserPassword(userPassword);
		
		
		if(game.consulGame(gm.getId()).getTsscSprints().size()>0 && game.consulGame(gm.getId()).getTsscGroups().size()>0) {
			topic.GameTopicSave(gm, topicId, adminPassword, guestPassword, nGroups, nSprints, name, pauseSeconds, scheduledDate, scheduledTime, startTime, typeGameId, userPassword);
		}
		
	}
	
	public boolean gameIntegration(TsscTopic topic,TsscGame game) {
		this.topic.topicSave(topic);
		this.game.gameSave(game);
		
		for(int i=0;i<topic.getDefaultGroups();i++) {
			TsscGroup group = new TsscGroup();
			group.setName("groupG"+i);
			this.game.addGroup(game.getId(), group);
			
		}
		
		for(int i=0;i<topic.getDefaultSprints();i++) {
			TsscSprint sprint = new TsscSprint();
			sprint.setNumber(new BigDecimal(i));
			this.game.addSprints(game.getId(), sprint);
		}
		
		boolean add = this.topic.GameTopicSave(game, topic.getId(), game.getAdminPassword(), game.getGuestPassword(), game.getNGroups(), game.getNSprints(), game.getName(), game.getPauseSeconds(), game.getScheduledDate(), game.getScheduledTime(), game.getStartTime(), game.getTypegameId(), game.getUserPassword());
		
		return add;
	}
	
	@Override
	public GameRepository getGameRepo() {
		return game;
	}

	@Override
	public TopicRepository getTopicRepo() {
		return topic;
	}

	@Override
	public StoryRepository getStoryRepo() {
		return story;
	}

	@Override
	public void deleteSprint(Long id, Long gameId) {
		game.deleteGroup(id, gameId);
		
	}

	@Override
	public void deleteGroup(Long id, Long gameId) {
		game.deleteSprint(id, gameId);
		
	}

	@Override
	public void deleteCronometer(Long id, Long gameId) {
		game.deleteCronometer(id, gameId);
	}

	@Override
	public boolean StorySave(TsscStory st, String altDescShown, String altDescription, BigDecimal businessValue,
			String description, BigDecimal initialSpring, BigDecimal number, BigDecimal priority,
			String shortDescription) {
		st.setAltDescShown(altDescShown);
		st.setAltDescripton(altDescription);
		st.setBusinessValue(businessValue);
		st.setDescription(description);
		st.setInitialSprint(initialSpring);
		st.setNumber(number);
		st.setPriority(priority);
		st.setShortDescription(shortDescription);
		
		if(st.getInitialSprint().toBigIntegerExact().intValue()>0 && st.getPriority().toBigIntegerExact().intValue()>0) {
			story.stSave(st);
			return true;
		}
		return false;
	}

	@Override
	public void addCronometer(TsscTimecontrol timeControl, Long id) {
		time.addtimeControlGame(timeControl, id);
		game.addCronometer(timeControl, id);
		
	}

	@Override
	public void editCronometer(Long id,String autoStart, BigDecimal intervalRunning,
			LocalTime lastPlayTime, String name, BigDecimal order, String state, BigDecimal timeInterval, String type) {
		time.editTimeControl(id,autoStart, intervalRunning, lastPlayTime, name, order, state, timeInterval, type);
	}
}
