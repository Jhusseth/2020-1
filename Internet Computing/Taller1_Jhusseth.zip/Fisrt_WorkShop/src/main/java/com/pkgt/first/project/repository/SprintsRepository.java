package com.pkgt.first.project.repository;

import java.util.Map;

import com.pkgt.first.project.model.TsscSprint;

public interface SprintsRepository {
	
	public void addSprints(TsscSprint sp); 
	public Map<Long,TsscSprint> getSprints();
	public void delete(Long id);

}
