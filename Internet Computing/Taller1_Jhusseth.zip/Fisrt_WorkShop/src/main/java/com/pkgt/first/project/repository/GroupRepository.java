package com.pkgt.first.project.repository;

import java.util.Map;

import com.pkgt.first.project.model.TsscGroup;
public interface GroupRepository {
	
	public void addGroup(TsscGroup group);
	public Map<Long,TsscGroup> getGroups();
	public void delete(Long id);

}
