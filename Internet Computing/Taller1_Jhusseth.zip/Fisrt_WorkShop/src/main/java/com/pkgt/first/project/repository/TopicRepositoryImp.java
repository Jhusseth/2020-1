package com.pkgt.first.project.repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.pkgt.first.project.model.TsscGame;
import com.pkgt.first.project.model.TsscTopic;
import java.util.Map;

@Repository
public class TopicRepositoryImp implements TopicRepository {
	
	private  Map<Long,TsscTopic> topics;
	
	@Autowired
	private GameRepository game;
	
	
	public TopicRepositoryImp() {
		topics = new HashMap<Long,TsscTopic>();
	}
	
	@Override
	public void topicSave(TsscTopic tp) {
		topics.put(tp.getId(), tp);
	}

	@Override
	public void topicEdit(Long id,String description, String name, Long sprints, Long groups, String groupPrefix) {
		
		TsscTopic tp = topics.get(id);
		
		if(tp!=null) {
			tp.setId(id);
			tp.setDescription(description);
			tp.setName(name);
			tp.setDefaultSprints(sprints);
			tp.setDefaultGroups(groups);
			tp.setGroupPrefix(groupPrefix);
			
			topics.remove(id);
			topics.put(tp.getId(), tp);	
		}
		
	}
	
	@Override
	public boolean GameTopicSave(TsscGame gm,Long topicId, String adminPassword, String guestPassword, Integer nGroups,
			Integer nSprints, String name, Long pauseSeconds, LocalDate scheduledDate, LocalTime scheduledTime,
			LocalTime startTime, BigDecimal typeGameId, String userPassword) {
		
		gm.setAdminPassword(adminPassword);
		gm.setGuestPassword(guestPassword);
		gm.setName(name);
		gm.setNGroups(nGroups);
		gm.setNSprints(nSprints);
		gm.setPauseSeconds(pauseSeconds);
		gm.setScheduledDate(scheduledDate);
		gm.setScheduledTime(scheduledTime);
		gm.setStartTime(startTime);
		gm.setTypegameId(typeGameId);
		gm.setUserPassword(userPassword);
		
		
		if(gm.getTsscSprints().size()>0 && gm.getTsscGroups().size()>0) {
			SaveTopicGame(topicId, gm);
			return true;
		}
		
		return false;
		
	}
	

	public boolean existTopic(Long topicId) {
		
		TsscTopic tp = consultTopic(topicId);
		
		if(tp!=null) {
			return true;
		}
		else {
			return false;	
		}
	}
	

	public void SaveTopicGame(Long topicId, TsscGame game) {
		
		if(existTopic(topicId)==true) {
			game.setTsscTopic(consultTopic(topicId));
			this.game.gameSave(game);
		}
	}

	@Override
	public TsscTopic consultTopic(Long id) {	
		return topics.get(id);	
	}
	
	@Override
	public Map<Long, TsscTopic> getTopics() {
		return topics;
	}

}
