package com.pkgt.first.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FisrtWorkShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(FisrtWorkShopApplication.class, args);
	}

}
