package com.pkgt.first.project.repository;

import java.math.BigDecimal;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.pkgt.first.project.model.TsscGame;
import com.pkgt.first.project.model.TsscTimeInterval;
import com.pkgt.first.project.model.TsscTimecontrol;
import com.pkgt.first.project.model.TsscTopic;

@Repository
public class CronometerRepositoryImp implements CronometerRepository {

	public Map<Long,TsscTimecontrol> times;
	
	@Autowired
	private GameRepository game;
	
	@Autowired
	private TopicRepository topic;
	

	public CronometerRepositoryImp() {
		this.times = new HashMap<>();
	}

	@Override
	public void editTimeControl(Long id,String autoStart, BigDecimal intervalRunning, LocalTime lastPlayTime, String name,
			BigDecimal order, String state, BigDecimal timeInterval, String type) {
		// TODO Auto-generated method stub
		TsscTimecontrol timeControl =  times.get(id);
		
		if(timeControl!=null) {
			if(timeControl.getTsscGame()==null) {
				timeControl.setAutostart(autoStart);
				timeControl.setIntervalRunning(intervalRunning);
				timeControl.setLastPlayTime(lastPlayTime);
				timeControl.setName(name);
				timeControl.setOrder(order);
				timeControl.setState(state);
				timeControl.setTimeInterval(timeInterval);
				timeControl.setType(type);
				
				times.remove(timeControl.getId());
				times.put(timeControl.getId(), timeControl);
			}
		}	
		
	}
	
	@Override
	public Map<Long, TsscTimecontrol> getTimes() {
		return times;
	}
	
	@Override
	public void addtimeControlGame(TsscTimecontrol time,Long id) {
		TsscGame gm = consultGame(id);
		time.setTsscGame(gm);
	}
	
	@Override
	public void addtimeControlTopic(TsscTimecontrol time,Long id) {
		TsscTopic tp = consultTopic(id);
		time.setTsscTopic(tp);
	}
	
	
	public TsscTopic consultTopic(Long topicId) {
		return topic.consultTopic(topicId);
	}
	
	public TsscGame consultGame(Long gameId) {
		return game.consulGame(gameId);
	}

	@Override
	public void deleteCronometer(Long id,Long gameId) {
		game.consulGame(gameId).removeTsscTimecontrol(times.get(id));
		times.remove(id);
		
	}

}
