package com.pkgt.first.project.repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

import com.pkgt.first.project.model.TsscGame;
import com.pkgt.first.project.model.TsscGroup;
import com.pkgt.first.project.model.TsscSprint;
import com.pkgt.first.project.model.TsscStory;
import com.pkgt.first.project.model.TsscTimecontrol;
import com.pkgt.first.project.model.TsscTopic;

public interface GameRepository {
	
	public void gameSave(TsscGame game);
	public void gameEdit(Long id,String adminPassword,String guestPassword,Integer nGroups,Integer nSprints,String name,
			Long pauseSeconds,LocalDate scheduledDate,LocalTime scheduledTime,LocalTime startTime,BigDecimal typeGameId,
			String userPassword);
	
	public void SaveTopicGame(TsscTopic topic,TsscGame game);
	
	public TsscGame consulGame(Long id);
	
	public Map<Long,TsscGame> getGame();
	
	public void addGroup(Long gameId,TsscGroup group);
	public void addSprints(Long gameId,TsscSprint sprint);
	
	public void deleteCronometer(Long id,Long gameId);
	public void deleteSprint(Long id,Long gameId);
	public void deleteGroup(Long id,Long gameId);
	public List<TsscTimecontrol> getTime();
	public void addCronometer(TsscTimecontrol timeControl,Long id);
}
