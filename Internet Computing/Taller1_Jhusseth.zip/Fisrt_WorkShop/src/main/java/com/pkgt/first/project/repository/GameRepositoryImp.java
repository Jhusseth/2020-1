package com.pkgt.first.project.repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mockito.internal.stubbing.answers.ThrowsException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.pkgt.first.project.model.TsscGame;
import com.pkgt.first.project.model.TsscGroup;
import com.pkgt.first.project.model.TsscSprint;
import com.pkgt.first.project.model.TsscTimecontrol;
import com.pkgt.first.project.model.TsscTopic;


@Repository
public class GameRepositoryImp implements GameRepository{
	
	public Map<Long,TsscGame> game;
	public List<TsscTimecontrol> time;;
	
	@Autowired
	private GroupRepository group;
	
	@Autowired
	private SprintsRepository sprints;
	
	
	
	
	public GameRepositoryImp() {
		
		game = new HashMap<>();
		time = new ArrayList<>();
		
	}

	@Override
	public void gameSave(TsscGame nGame){
		if(!(game.size()==0)) {
			for(int i=1;i<=game.size();i++) {
				if((nGame.getScheduledDate()!=game.get((long)i).getScheduledDate())&&
						nGame.getScheduledTime()!=game.get((long)i).getScheduledTime()) {
					game.put(nGame.getId(),nGame);
				}
				else {
					new ThrowsException(new Throwable("exist a topic in the same schedule"));
				}
			}
		}
		else {
			game.put(nGame.getId(),nGame);
		}
	}

	@Override
	public void gameEdit(Long id, String adminPassword, String guestPassword, Integer nGroups, Integer nSprints,
			String name, Long pauseSeconds, LocalDate scheduledDate, LocalTime scheduledTime, LocalTime startTime,
			BigDecimal typeGameId, String userPassword) {
		
		TsscGame gm = game.get(id);
		
		if(gm!=null) {
			gm.setId(id);
			gm.setAdminPassword(adminPassword);
			gm.setGuestPassword(guestPassword);
			gm.setName(name);
			gm.setNGroups(nGroups);
			gm.setNSprints(nSprints);
			gm.setPauseSeconds(pauseSeconds);
			gm.setScheduledDate(scheduledDate);
			gm.setScheduledTime(scheduledTime);
			gm.setStartTime(startTime);
			gm.setTypegameId(typeGameId);
			gm.setUserPassword(userPassword);
			
			game.remove(id);
			game.put(gm.getId(),gm);
		}
	}

	@Override
	public void SaveTopicGame(TsscTopic topic, TsscGame game) {
		
		if(topic!=null) {
			game.setTsscTopic(topic);
			gameSave(game);
		}
	}

	@Override
	public TsscGame consulGame(Long id) {
		return game.get(id);
	}
	
	
	@Override
	public Map<Long,TsscGame> getGame(){
		return game;
	}
	
	@Override
	public List<TsscTimecontrol> getTime() {
		return time;
	}
	
	@Override
	public void addSprints(Long gameId,TsscSprint sprint) {
		this.sprints.addSprints(sprint);
		game.get(gameId).addTsscSprint(this.sprints.getSprints().get(sprint.getId()));
	}
	
	@Override
	public void addGroup(Long gameId,TsscGroup group) {
		this.group.addGroup(group);
		game.get(gameId).addTsscGroup(this.group.getGroups().get(group.getId()));
		
	}

	public GroupRepository getGroup() {
		return group;
	}

	public SprintsRepository getSprints() {
		return sprints;
	}
	
	
	public void addCronometer(TsscTimecontrol timeControl,Long id) {
		time.add(timeControl);
		consulGame(id).addTsscTimecontrol(timeControl);
	}

	@Override
	public void deleteSprint(Long id,Long gameId) {
		consulGame(gameId).removeTsscSprint(sprints.getSprints().get(id));
		sprints.delete(id);
	}

	@Override
	public void deleteGroup(Long id,Long gameId) {
		consulGame(gameId).removeTsscGroup(group.getGroups().get(id));
		group.delete(id);
	}

	@Override
	public void deleteCronometer(Long id, Long gameId) {
		TsscTimecontrol tm = null;
		for(TsscTimecontrol tm2:getTime()) {
			if(tm2.getId()==id) {
				tm=tm2;
			}
		}
		consulGame(gameId).removeTsscTimecontrol(tm);
	}
}
