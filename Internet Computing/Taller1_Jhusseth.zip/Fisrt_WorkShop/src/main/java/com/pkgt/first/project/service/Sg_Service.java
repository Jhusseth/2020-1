package com.pkgt.first.project.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

import org.springframework.stereotype.Repository;

import com.pkgt.first.project.model.TsscGame;
import com.pkgt.first.project.model.TsscStory;
import com.pkgt.first.project.model.TsscTimecontrol;
import com.pkgt.first.project.model.TsscTopic;
import com.pkgt.first.project.repository.GameRepository;
import com.pkgt.first.project.repository.StoryRepository;
import com.pkgt.first.project.repository.TopicRepository;

public interface Sg_Service {
	
	public void TopicEdit(Long id,String description, String name, Long Sprints, Long Groups, String group);

	public boolean TopicSave(TsscTopic tp,String description, String name, Long Sprints, Long Groups, String group);
	
	public void GameEdit(Long id,String adminPassword,String guestPassword,Integer nGroups,Integer nSprints,String name,
			Long pauseSeconds,LocalDate scheduledDate,LocalTime scheduledTime,LocalTime startTime,BigDecimal typeGameId,
			String userPassword);
	
	public boolean GameSave(TsscGame gm,String adminPassword,String guestPassword,Integer nGroups,Integer nSprints,String name,
			Long pauseSeconds,LocalDate scheduledDate,LocalTime scheduledTime,LocalTime startTime,BigDecimal typeGameId,
			String userPassword);
	
	public void StoryEdit(Long gameId,Long id,String altDescShow,String altDescription,BigDecimal businessValue,String descripcion,
			BigDecimal initialSpring,BigDecimal number,BigDecimal priority,String ShortDescription);
	
	public boolean StorySaveGame(TsscStory st,Long gameId,String altDescShow,String altDescription,BigDecimal businessValue,String descripcion,
			BigDecimal initialSpring,BigDecimal number,BigDecimal priority,String ShortDescription);
	
	public boolean StorySave(TsscStory st,String altDescShow,String altDescription,BigDecimal businessValue,String descripcion,
			BigDecimal initialSpring,BigDecimal number,BigDecimal priority,String ShortDescription);
	
	public void GameTopicSave(TsscGame gm ,Long topicId,String adminPassword,String guestPassword,Integer nGroups,Integer nSprints,String name,
			Long pauseSeconds,LocalDate scheduledDate,LocalTime scheduledTime,LocalTime startTime,BigDecimal typeGameId,
			String userPassword);

	public GameRepository getGameRepo();
	public TopicRepository getTopicRepo();
	public StoryRepository getStoryRepo();
	
	public void addCronometer(TsscTimecontrol timeControl,Long id);
	public void editCronometer(Long id,String autoStart,BigDecimal intervalRunning,LocalTime lastPlayTime,String name,
			BigDecimal order,String state,BigDecimal timeInterval,String type);
	
	
	public void deleteSprint(Long id,Long gameId);
	public void deleteGroup(Long id,Long gameId);
	public void deleteCronometer(Long id,Long gameId);

}
