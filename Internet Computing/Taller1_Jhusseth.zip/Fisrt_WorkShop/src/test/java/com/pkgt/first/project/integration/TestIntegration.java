package com.pkgt.first.project.integration;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.pkgt.first.project.model.TsscGame;
import com.pkgt.first.project.model.TsscGroup;
import com.pkgt.first.project.model.TsscSprint;
import com.pkgt.first.project.model.TsscStory;
import com.pkgt.first.project.model.TsscTimecontrol;
import com.pkgt.first.project.model.TsscTopic;
import com.pkgt.first.project.service.Sg_Service;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TestIntegration {
	
	@Autowired
	public Sg_Service service;
	
	
	@Before
	public void setUp() {
	
		TsscStory story = new TsscStory();
		story.setId((long)1);
		story.setDescription("first history");
		
		TsscTopic topic = new TsscTopic();
		topic.setId((long)1);
		topic.setName("topic 1");
		
		List<TsscGroup> tsscGroups = new ArrayList<>();
		List<TsscSprint>tsscSprints= new ArrayList<>();
		List<TsscStory> tsscStories= new ArrayList<>();
		
		TsscGame game = new TsscGame();
		game.setId((long)1);
		game.setAdminPassword("adminPassword");
		game.setGuestPassword("guestPassword");
		game.setNGroups(5);
		game.setNSprints(4);
		game.setName("name");
		game.setPauseSeconds((long)2);
		game.setScheduledDate(LocalDate.now());
		game.setScheduledTime(LocalTime.of(12, 30));
		game.setStartTime(LocalTime.now());
		game.setTypegameId(new BigDecimal(10));
		game.setUserPassword("userPassword");
		game.setTsscGroups(tsscGroups);
		game.setTsscSprints(tsscSprints);
		game.setTsscStories(tsscStories);
		
		service.getGameRepo().gameSave(game);
		service.getStoryRepo().stSave(story);
		service.getTopicRepo().topicSave(topic);
		
		
	}
	
	@Test
	public void testTopicSave() {
		TsscTopic topic = service.getTopicRepo().getTopics().get((long)1);
		assertEquals(true, service.TopicSave(topic,"topic for service of gestion", "topic1", (long)3, (long) 4,"00"));
	}
	
	@Test
	public void testSaveGame() {
		TsscGame gm = service.getGameRepo().consulGame((long)1);
		TsscGroup group = new TsscGroup();
		group.setName("groupG");
		TsscSprint sprint = new TsscSprint();
		sprint.setNumber(new BigDecimal(5));
		
		service.getGameRepo().addGroup(gm.getId(), group);
		service.getGameRepo().addSprints(gm.getId(), sprint);
		
		assertEquals(true,service.GameSave(gm,gm.getAdminPassword(), gm.getGuestPassword(),gm.getNGroups(),gm.getNSprints(),gm.getName(),gm.getPauseSeconds(),gm.getScheduledDate(),gm.getScheduledTime(),gm.getStartTime(),gm.getTypegameId(),gm.getUserPassword()));
	}
	
	@Test
	public void testStory() {
		TsscStory story = service.getStoryRepo().getStorys().get((long)1);
		assertEquals(true,service.StorySaveGame(story,(long)1, "altDescShow", "altDescription", new BigDecimal(4), story.getDescription(), new BigDecimal(3), new BigDecimal(4), new BigDecimal(5), "ShortDescription"));
	}
	
	@Test
	public void testGameIntegration() {
		TsscTopic topic = new TsscTopic();
		topic.setDefaultGroups((long)2);
		topic.setDefaultSprints((long)3);
		topic.setName("topic integration");
		assertEquals(true, service.TopicSave(topic,"topic for service of gestion", "topic1", (long)3, (long) 4,"00"));
		
		TsscGame game = service.getGameRepo().consulGame((long)1);
		
		for(int i=0;i<topic.getDefaultGroups();i++) {
			TsscGroup group = new TsscGroup();
			group.setName("groupG"+i);
			service.getGameRepo().addGroup(game.getId(), group);
			
		}
		
		for(int i=0;i<topic.getDefaultSprints();i++) {
			TsscSprint sprint = new TsscSprint();
			sprint.setNumber(new BigDecimal(i));
			service.getGameRepo().addSprints(game.getId(), sprint);
		}
		
		assertEquals(true,service.getTopicRepo().GameTopicSave(game, (long)10, "adminPassword", "guestPassword", 2, 3, "integratin Game", (long)3, LocalDate.now(), LocalTime.of(15, 22), LocalTime.now(), new BigDecimal(3), "userPassword"));
				
	}
	
	@Test
	public void deletes() {
		
		TsscGame game = service.getGameRepo().consulGame((long)1);
		TsscTimecontrol tc = new TsscTimecontrol();
		tc.setName("name1");
		TsscTimecontrol tc2 = new TsscTimecontrol();
		tc2.setName("name2");
		TsscTimecontrol tc3 = new TsscTimecontrol();
		tc3.setName("name3");
		
		service.addCronometer(tc, game.getId());
		service.addCronometer(tc2, game.getId());
		service.addCronometer(tc3, game.getId());
		
		service.getGameRepo().consulGame((long)1).setTsscTimecontrol(service.getGameRepo().getTime());
		
		assertEquals(3,service.getGameRepo().consulGame((long)1).getTsscTimecontrols().size());
		
		service.deleteCronometer(tc2.getId(), game.getId());
		service.deleteCronometer(tc.getId(), game.getId());
		
		assertEquals(1,service.getGameRepo().consulGame((long)1).getTsscTimecontrols().size());
		
		TsscGroup group = new TsscGroup();
		group.setName("groupG");
		service.getGameRepo().addGroup(game.getId(), group);
		
		
		TsscGroup group2 = new TsscGroup();
		group2.setName("groupG");
		service.getGameRepo().addGroup(game.getId(), group2);
		
		TsscSprint sprint = new TsscSprint();
		sprint.setNumber(new BigDecimal(1));
		service.getGameRepo().addSprints(game.getId(), sprint);
		
		TsscSprint sprint2 = new TsscSprint();
		sprint2.setNumber(new BigDecimal(1));
		service.getGameRepo().addSprints(game.getId(), sprint2);
		
		
		assertEquals(2,service.getGameRepo().consulGame((long)1).getTsscGroups().size());
		assertEquals(2,service.getGameRepo().consulGame((long)1).getTsscSprints().size());
		
		
		service.deleteGroup(group.getId(), game.getId());
		service.deleteSprint(sprint.getId(), game.getId());
		
		assertEquals(1,service.getGameRepo().consulGame((long)1).getTsscGroups().size());
		assertEquals(1,service.getGameRepo().consulGame((long)1).getTsscSprints().size());
		
	}
	
	@Test
	public void testSaveGame2() {
		
	}
	
	
	

}
