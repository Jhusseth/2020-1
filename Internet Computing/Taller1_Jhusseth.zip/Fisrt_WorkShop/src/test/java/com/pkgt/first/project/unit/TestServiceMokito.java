package com.pkgt.first.project.unit;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.pkgt.first.project.model.TsscGame;
import com.pkgt.first.project.model.TsscGroup;
import com.pkgt.first.project.model.TsscSprint;
import com.pkgt.first.project.model.TsscStory;
import com.pkgt.first.project.model.TsscTopic;
import com.pkgt.first.project.repository.GameRepository;
import com.pkgt.first.project.repository.StoryRepository;
import com.pkgt.first.project.repository.TopicRepository;
import com.pkgt.first.project.service.Sg_ServiceImp;

@SpringBootTest()
@RunWith(MockitoJUnitRunner.class)
public class TestServiceMokito {
	
	@InjectMocks
	@Autowired
	private Sg_ServiceImp service;
	
	@Mock
	private GameRepository gameRepo;
	@Mock
	private StoryRepository storyRepo;
	@Mock
	private TopicRepository topicRepo;
	
	
	@Before 
    public void initMocks() {
        MockitoAnnotations.initMocks(this);
    }
	
	
	@Test
	public void testSaveGame() {
		
		
		List<TsscGroup> tsscGroups = new ArrayList<>();
		List<TsscSprint>tsscSprints= new ArrayList<>();
		List<TsscStory> tsscStories= new ArrayList<>();
		
		TsscGroup group = new TsscGroup();
		group.setName("groupG");
		TsscSprint sprint = new TsscSprint();
		sprint.setNumber(new BigDecimal(5));
		
		TsscGame gm = new TsscGame();
		
		gm.setId((long)1);
		gm.setAdminPassword("adminPassword");
		gm.setGuestPassword("guestPassword");
		gm.setNGroups(5);
		gm.setNSprints(4);
		gm.setName("name");
		gm.setPauseSeconds((long)2);
		gm.setScheduledDate(LocalDate.now());
		gm.setScheduledTime(LocalTime.of(12, 30));
		gm.setStartTime(LocalTime.now());
		gm.setTypegameId(new BigDecimal(10));
		gm.setUserPassword("userPassword");
		gm.setTsscGroups(tsscGroups);
		gm.setTsscSprints(tsscSprints);
		gm.setTsscStories(tsscStories);
		gm.addTsscGroup(group);
		gm.addTsscSprint(sprint);
		
		gameRepo.gameSave(gm);
		
		
	}
	
	
	@Test
	public void testSaveTopic() {
		
		TsscTopic topic = new TsscTopic();
		topic.setId((long)1);
		topic.setName("topic 1");
		topicRepo.topicSave(topic);
		service.TopicSave(topic,"topic for service of gestion", "topic1", (long)3, (long) 4,"00");
	}
	
	
	@Test
	public void testSaveStory() {
		
		TsscStory storyAux = new TsscStory();
		service.StorySaveGame(storyAux,(long)1, "altDescShow", "altDescription", new BigDecimal(4), storyAux.getDescription(), new BigDecimal(3), new BigDecimal(4), new BigDecimal(5), "ShortDescription");	
	}
	

}
